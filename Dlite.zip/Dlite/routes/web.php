<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controller\UserController;
use App\Http\Controller\SignupController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// Route::get('/', function () {
//     return view('master');
// });
Route::get('/','App\Http\Controllers\Product@retrive1');

    Route::get('/master','App\Http\Controllers\Product@retrive1');
    Route::get('/orderdata','App\Http\Controllers\Orderfullfill@getdata');
    Route::get('deleteorder/{id}','App\Http\Controllers\Orderfullfill@destroy');
    Route::get('updateorder/{id}','App\Http\Controllers\Orderfullfill@updateorder');

    // Route::get('/MASTER', function () {
    //     return view('master');
    // });
Route::get('/about', function () {
    return view('About');
});
Route::get('/id', function () {
    return view('id');
});

// Route::get('/loginWelcome', function () {
//     //view('LoginWelcome');
//     return view('master');
// });
Route::get('/home','App\Http\Controllers\Product@retrive1');
// Route::get('/home',function(){
//     return view('master');
// });

Route::get('/contact',function(){
    return view('contact');
});
Route::get('/cloth',function(){
    return view('Women/Cloth');
});
Route::get('/login',function()
{
return view('login');
});
Route::get('/signup',function()
{
return view('Signup');
});
Route::get('/account',function()
{
    return view('Account');
});

//creating route for Men link
// Route::get('/mencloths',function()
// {
//     return view('Men\Cloth');
// });
Route::get('mencloth','App\Http\Controllers\Product@mencloth');

Route::get('/menwallet','App\Http\Controllers\Product@menwallet');

// Route::get('/menwallet',function()
// {
//     return view('Men\Wallet');
// });
Route::get('/menwatch','App\Http\Controllers\Product@menwatch');
// Route::get('/menwatch',function()
// {
//     return view('Men\Watch');
// });
Route::get('/menbag','App\Http\Controllers\Product@menbag');
// Route::get('/menbag',function()
// {
//     return view('Men\bag');
// });
Route::get('/menjewellery','App\Http\Controllers\Product@menjewellery');
// Route::get('/menjwellery',function()
// {
//     return view('Men\jewellery');
// });

Route::get('/mensunglasses','App\Http\Controllers\Product@mensunglasses');
// Route::get('/mensunglasses',function()
// {
//     return view('Men\sunglasses');
// });
Route::get('/menfootwear','App\Http\Controllers\Product@menshoes');
// Route::get('/menfootwear',function()
// {
//     return view('Men\Footwear');
// });

Route::get('/menperfume','App\Http\Controllers\Product@menperfume');
// Route::get('/menperfume',function()
// {
//     return view('Men\perfume');
// });

//creating routes  for Women
Route::get('/womencloth','App\Http\Controllers\Product@womencloth');
// Route::get('/womencloth',function()
// {
//     return view('Women\Cloth');
// });

Route::get('/womenwallet','App\Http\Controllers\Product@womenwallet');
// Route::get('/womenwallet',function()
// {
//     return view('Women\Wallet');
// });

Route::get('/womenwatch','App\Http\Controllers\Product@womenwatch');
// Route::get('/womenwatch',function()
// {
//     return view('Women\Watch');
// });

Route::get('/womenbag','App\Http\Controllers\Product@womenbag');
// Route::get('/womenbag',function()
// {
//     return view('Women\bag');
// });

Route::get('/womenjewellery','App\Http\Controllers\Product@womenjewellery');
// Route::get('/womenjwellery',function()
// {
//     return view('Women\jewellery');
// });

Route::get('/womensunglasses','App\Http\Controllers\Product@womensunglasses');
// Route::get('/womensunglasses',function()
// {
//     return view('Women\sunglasses');
// });

Route::get('/womenfootwear','App\Http\Controllers\Product@womenfootwear');
// Route::get('/womenfootwear',function()
// {
//     return view('Women\Footwear');
// });

Route::get('/womenperfume','App\Http\Controllers\Product@womenperfume');
// Route::get('/womenperfume',function()
// {
//     return view('Women\perfume');
// });

//Kids Routes

Route::get('/kidcloth','App\Http\Controllers\Product@kidcloth');
// Route::get('/womencloth',function()
// {
//     return view('Women\Cloth');
// });

Route::get('/kidwallet','App\Http\Controllers\Product@kidwallet');
// Route::get('/womenwallet',function()
// {
//     return view('Women\Wallet');
// });

Route::get('/kidwatch','App\Http\Controllers\Product@kidwatch');
// Route::get('/womenwatch',function()
// {
//     return view('Women\Watch');
// });

Route::get('/kidbag','App\Http\Controllers\Product@kidbag');
// Route::get('/womenbag',function()
// {
//     return view('Women\bag');
// });

Route::get('/kidjewellery','App\Http\Controllers\Product@kidjewellery');
// Route::get('/womenjwellery',function()
// {
//     return view('Women\jewellery');
// });

Route::get('/kidsunglasses','App\Http\Controllers\Product@kidsunglasses');
// Route::get('/womensunglasses',function()
// {
//     return view('Women\sunglasses');
// });

Route::get('/kidfootwear','App\Http\Controllers\Product@kidfootwear');
// Route::get('/womenfootwear',function()
// {
//     return view('Women\Footwear');
// });

Route::get('/kidperfume','App\Http\Controllers\Product@kidperfume');
// Route::get('/womenperfume',function()
// {
//     return view('Women\perfume');
// });

//cart
Route::get('/cart','App\Http\Controllers\AddCart@cartretrive');
// Route::get('/cart',function()
// {
//     return view('Cart');
// });
// Route::view('form','login');
Route::post('submit', 'App\Http\Controllers\SignupController@store');//this method work in this laravel project
Route::post('submitproduct', 'App\Http\Controllers\Product@addproduct');
Route::get('data','App\Http\Controllers\LoginController@retrive1');
Route::post('submitlogin','App\Http\Controllers\LoginController@retrive');
Route::post('submitcart','App\Http\Controllers\AddCart@store');
Route::get('editproduct','App\Http\Controllers\Product@retriveproductforedit');
Route::post('updateproduct','App\Http\Controllers\Product@updateproduct');
Route::post('updateaccount','App\Http\Controllers\LoginController@updateaccount');
Route::get('delete/{id}','App\Http\Controllers\SignupController@destroy');
Route::get('deleteproduct/{id}','App\Http\Controllers\Product@destroy');
Route::get('deletecart/{id}','App\Http\Controllers\AddCart@destroy');
Route::post('orderproduct','App\Http\Controllers\Orderfullfill@getorder');
Route::post('message','App\Http\Controllers\ChatMessagesController@store');
Route::get('chat','App\Http\Controllers\ChatMessagesController@retrive');
Route::get('delete/{id}','App\Http\Controllers\ChatMessagesController@destroy');
// Route::post('submit', [UserController::class, 'save']);
//  Route::post('submit','Controller@save');
// Route::view("/login","login");
// Route::post("/login",[UserController::class],'login');


Route::get('/admin','App\Http\Controllers\Dashboard@Dashboardretrive');
Route::get('/sales','App\Http\Controllers\Dashboard@Salesretrive');
// Route::get('/admin', function () {
//     return view('admin');
// });
Route::get('/addproduct', function () {
    return view('Addproduct');
});