<html>
    <head> <title>Womens Watch</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script></head>
    <body>
    

    
        {{View::make('header')}}
       
        @if(session('status'))
        <h2 style="text-align:center" class="alert alert Success">{{session('status')}}</h2>
        @endif
  <div class="container">
@foreach($data as $Product)

@if($Product->Category=="Women")

@if($Product->SubCategory=="Watches")
<div class="col-md-3    bg-warning" style="background-color: black;border:1px solid black;margin-top:20px;margin-right:10px;margin-left:10px;height:400px">
<form action="submitcart" method="post">
@csrf

<input type="hidden" id="custId" name="name" value="{{ $Product->Name }}">
<input type="hidden" id="custId" name="price" value="{{ $Product->Price }}">
<input type="hidden" id="custId" name="size" value="{{ $Product->size }}">
<input type="hidden" id="custId" name="Userid" value="{{$loginid}}">

<input type="hidden" id="custId" name="Brand" value="{{$Product->Brand}}">
<input type="hidden" id="custId" name="Category" value="{{$Product->Category}}">
<input type="hidden" id="custId" name="SubCategory" value="{{$Product->SubCategory}}">
<input type="hidden" id="custId" name="Discount" value="{{$Product->Discount}}">
<input type="hidden"  name="Image" value="{{$Product->Image}}">

  <div name="image" value="{{ asset('image/' . $Product->Image) }}" style="width:250px;height:250px;border:1px solid black"> <img style="width:250px;height:250px;" src="{{ asset('image/' . $Product->Image) }}" alt="Any alt text"/>  </div>
  <h2 price="name" value="{{ $Product->Name }}" style="background-color: Orange;
  color: white;border:1px solid black;font-style: italic;text-align:center" >{{ $Product->Name }}</h2>
  <h2 name="price" value="{{ $Product->Price }}" style="background-color: black;
  color: white;font-style: oblique;font-size: 20px;">Price:     ${{ $Product->Price }}</h2>
  <h2 name="size" style="background-color: black;
  color: white;font-style: oblique;font-size: 20px;">Size:  {{ $Product->size }}</h2>
  <h2  style="background-color: black;
  color: white;font-style: oblique;font-size:12px;">{{$Product->Description}}</h2>
  <h2 name="Userid" value="{{$loginid}}"></h2>
  <h2 name="Brand" value="{{$Product->Brand}}"></h2>
  <h2 name="Category" value="{{$Product->Category}}"></h2>
  <h2 name="SubCategory" value="{{$Product->SubCategory}}"></h2>
  <h2 name="Discount" value="{{$Product->Discount}}"></h2>
  <button  style="background-color: Orange;
  color: white;">Add Cart</button>

</form>

  </div>
  @endif
@endif

@endforeach
  </div>


       <br><br><br><br><br><br><br><br>
      {{View::make('footer')}}
    
    </body>
</html>