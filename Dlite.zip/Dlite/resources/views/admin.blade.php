    <html>
        <head>
            <title>Admin Panel</title>
        </head>
        <body>
        <div style="background-color:white;background-image: url('{{URL::asset('/photos/admin.jpg')}}')">
        <header style="height:100px;width:102%;border:1px solid black;background-color:Orange">

<!-- <div> <img style="height:100px;width:40%;"src="{{URL::asset('/photos/delite.jpg')}}" alt=""></div> -->
<h1 style="text-align:center;font-size:60px;vertical-align: text-top; text-shadow: 2px 2px white;">Dlite Shopping</h1>
</header>
<aside style="width:200px;height:100%; border:1px solid black">
<div ><button style="height:10%;width:100%;background-color:Orange;"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;" href="{{('admin')}}">  Dashboard</a></button></div>
<div ><button style="height:10%;width:100%;"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;"href="{{('sales')}}">Sales</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;;text-shadow: 2px 2px black;"href="{{('chat')}}">Chats</a> </button></div>
<div ><button style="height:10%;width:100%"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;" href="{{('data')}}">Account</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;"href="{{('addproduct')}}">Add Product</a> </button></div>
<div ><button style="height:10%;width:100%"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;"href="{{('editproduct')}}">Edit Product</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;"href="{{('orderdata')}}">Orders</a> </button></div>

</aside>
<!-- section part where thing will be shown -->
<div style="position: absolute; top:120px; left:220px;;width:85%;">

<table style="border:1px solid black;background-color:Orange">
  <tr>

    <th > <div style="box-shadow: 10px 10px 5px  lightblue;background-color:	#a9a9a9;color:white;height:200px;width:330px;border:1px solid black;text-align:center;border-radius: 100px;"> <h1 style="text-align:center;text-shadow: 2px 2px black;">Sales :</h1><h1 style="text-align:center">{{$sales}}</h1></div></th>
    <th ><div style="box-shadow: 10px 10px 5px  lightblue;background-color:black;color:white;height:200px;width:330px;border:1px solid black;text-align:center;border-radius: 100px;"> <h1 style="text-align:center;text-shadow: 2px 2px black;">Orders :</h1><h1 style="text-align:center">{{$orders}}</h1></div></th>
    <th ><div style="box-shadow: 10px 10px 5px  lightblue;background-color:	#a9a9a9;color:white;height:200px;width:330px;border:1px solid black;text-align:center;border-radius: 100px;"> <h1 style="text-align:center;text-shadow: 2px 2px black;">Users :</h1><h1 style="text-align:center">{{$users}}</h1></div></th>
  </tr>
</table>

</div>
</div>
        </body>
    </html>
  

