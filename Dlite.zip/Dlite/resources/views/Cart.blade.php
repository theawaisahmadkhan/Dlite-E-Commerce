<title>Dlite Shopping Cart</title>
{{View::make('header')}}

        @yield('content')
        <br><br><br><br>
        @if(session('status'))
        <h2 style="text-align:center" class="alert alert Success">{{session('status')}}</h2>
        @endif
        <div  style="margin:5%">
        <table>
              <tr>
                    <th style="width:80px;border:1px solid black;background-color:Orange;">Image</th>
                    <th style="width:150px;border:1px solid black;background-color:Orange">Product Name</th>
                    <th style="width:200px;border:1px solid black;background-color:Orange"> Quantity</th>
                    <th style="width:80px;border:1px solid black;background-color:Orange">Price</th>
              </tr>
        </table>
        @foreach ($data as $Product)
       @if($loginid!=0)
       
            <form action="orderproduct" method="post" >
             @csrf
             <input type="hidden" name="id" value="{{ $Product->id}}">
             <input type="hidden" name="Name" value="{{ $Product->Name}}">
             <input type="hidden" name="Image" value="{{ $Product->Image}}">
             <input type="hidden" name="Price" value="{{ $Product->Price}}">
             <input type="hidden" name="Userid" value="{{ $Product->Userid}}">
             <input type="hidden" name="Discount" value="{{ $Product->Discount}}">
             <input type="hidden" name="Brand" value="{{ $Product->Brand}}">
             <input type="hidden" name="Category" value="{{ $Product->Category}}">
             <input type="hidden" name="SubCategory" value="{{ $Product->SubCategory}}">
         <table style="border:1px solid Orange">
         <br>
         <tr style="border:1px solid Orange">
            <td style=";;"><img style="width:80px;height:100px;" src="{{ asset('image/' . $Product->Image) }}" alt="Any alt text"/>
            <td style="width:150px;border:1px solid black;background-color:grey;color:white;font-size:16px;text-align:center">{{$Product->Name}}</td>
            <td style="width:100px;border:1px solid black;background-color:Orange;">
            <input type="text" value="" name="Quantity" required="Please Enetr Quantity" placeholder="Enter Your Quantity"></td>
            <td style="width:80px;border:1px solid black;background-color:grey;color:white;font-size:16px">${{$Product->Price}}</td>
            <td style=";text-align:center;color:Black ;font-size:16px;background-color:Orange"><button type="submit">Order</button>/
            <button><a href='deletecart/{{ $Product->id }}'>Delete</a></button>
			</td>
         </tr>
        
         </table>
         </form>
       
       @endif
        
         @endforeach
     
        </div>
        


  {{View::make('footer')}}