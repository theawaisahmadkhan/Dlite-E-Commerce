
<html>
    <head> <title>Dlite Shopping</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script></head>
    <body>
   
        {{View::make('header')}}
        @yield('content')
  <div class="container">
    <br>
  <div style="width:100%;background-color:Orange;color:white;text-shadow: 3px 3px black;;font-size:40px;text-align:center">Mens</div>
@foreach($data as $Product)
@if($Product->Category=="Men")
<div class="col-md-3    bg-warning" style="background-color: black;border:1px solid black;margin-top:20px;margin-right:10px;margin-left:10px;height:400px">
<form action="">

<div style="width:250px;height:250px;border:1px solid black"> <img style="width:250px;height:250px;" src="{{ asset('image/' . $Product->Image) }}" alt="Any alt text"/>  </div>
<h2 style="background-color: Orange;
  color: white;border:1px solid black;font-style: italic;text-align:center" >{{ $Product->Name }}</h2>
<h2 style="background-color: black;
  color: white;font-style: oblique;font-size: 20px;">Price:     ${{ $Product->Price }} </h2>
  <h2 style="background-color: black;
  color: white;font-style: oblique;font-size: 20px;">Size:  {{ $Product->size }}</h2>
  <h2 style="background-color: black;
  color: white;font-style: oblique;font-size:12px;">{{$Product->Description}}</h2>
    <body>

<button name="{{$loginid}}" type="submit" style="background-color: Orange;
  color: white;">Add Cart</button>


</form>

  </div>
 
  @endif
@endforeach


  </div>
  <div class="container">
    <br>
  <div style="width:100%;background-color:Orange;color:white;font-size:40px;text-align:center;text-shadow: 3px 3px black;">Women</div>
@foreach($data as $Product)
@if($Product->Category=="Women")
<div class="col-md-3    bg-warning" style="background-color: black;border:1px solid black;margin-top:20px;margin-right:10px;margin-left:10px;height:400px">
<form action="" >

<div style="width:250px;height:250px;border:1px solid black"> <img style="width:250px;height:250px;" src="{{ asset('image/' . $Product->Image) }}" alt="Any alt text"/>  </div>
<h2 style="background-color: Orange;
  color: white;border:1px solid black;font-style: italic;text-align:center" >{{ $Product->Name }}</h2>
<h2 style="background-color: black;
  color: white;font-style: oblique;font-size: 20px;">Price:     ${{ $Product->Price }} </h2>
  <h2 style="background-color: black;
  color: white;font-style: oblique;font-size: 20px;">Size:  {{ $Product->size }}</h2>
  <h2 style="background-color: black;
  color: white;font-style: oblique;font-size:12px;">{{$Product->Description}}</h2>
    <body>

<button name="{{$loginid}}" style="background-color: Orange;
  color: white;">Add Cart</button>


</form>

  </div>
 
  @endif
@endforeach


  </div>
  <div class="container">
    <br>
<div style="width:100%;background-color:Orange;color:white;font-size:40px;text-align:center;text-shadow: 3px 3px black;">Kids</div>
@foreach($data as $Product)
@if($Product->Category=="Kid")
<div class="col-md-3    bg-warning" style="background-color: black;border:1px solid black;margin-top:20px;margin-right:10px;margin-left:10px;height:400px">
<form action="" >

<div style="width:250px;height:250px;border:1px solid black"> <img style="width:250px;height:250px;" src="{{ asset('image/' . $Product->Image) }}" alt="Any alt text"/>  </div>
<h2 style="background-color: Orange;
  color: white;border:1px solid black;font-style: italic;text-align:center" >{{ $Product->Name }}</h2>
<h2 style="background-color: black;
  color: white;font-style: oblique;font-size: 20px;">Price:     ${{ $Product->Price }} </h2>
  <h2 style="background-color: black;
  color: white;font-style: oblique;font-size: 20px;">Size:  {{ $Product->size }}</h2>
  <h2 style="background-color: black;
  color: white;font-style: oblique;font-size:12px;">{{$Product->Description}}</h2>
    <body>

<button name="{{$loginid}}" style="background-color: Orange;
  color: white;">Add Cart</button>


</form>

  </div>
 
  @endif
@endforeach


  </div>

       <br><br><br><br><br><br><br><br>
      {{View::make('footer')}}
    </body>
</html>