<html>
        <head>
            <title>Accounts</title>
            <style>
                table, th, td {
  border: 1px solid black;
}
            </style>
        </head>
        <body>
        <div>
        <header style="height:100px;width:102%;border:1px solid black;background-color:Orange">

<!-- <div> <img style="height:100px;width:40%;"src="{{URL::asset('/photos/delite.jpg')}}" alt=""></div> -->
<h1 style="text-align:center;font-size:60px;vertical-align: text-top; text-shadow: 2px 2px white;">Dlite Shopping</h1>
</header>
<aside style="width:200px;height:100%; border:1px solid black">
<div ><button style="height:10%;width:100%;background-color:Orange;"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;" href="{{('admin')}}">  Dashboard</a></button></div>
<div ><button style="height:10%;width:100%;"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;"href="{{('sales')}}">Sales</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;;text-shadow: 2px 2px black;"href="{{('chat')}}">Chats</a> </button></div>
<div ><button style="height:10%;width:100%"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;" href="{{('data')}}">Account</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;"href="{{('addproduct')}}">Add Product</a> </button></div>
<div ><button style="height:10%;width:100%"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;"href="{{('editproduct')}}">Edit Product</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;"href="{{('orderdata')}}">Orders</a> </button></div>

</aside>
<!-- section part where thing will be shown -->
<div style="position: absolute; top:120px; left:220px;border:1px solid black;width:85%;">

@if(session('status'))
        <h2 style="text-align:center" class="alert alert Success">{{session('status')}}</h2>
        @endif
<table>
  <tr>
    <th style="width:80px">Id</th>
    <th style="width:200px">Name</th>
    <th style="width:300px">Email</th>
    <th style="width:200px">Passward</th>
    <th style="width:200px">Edit/Delete</th>
  </tr>
</table>

    <table style="">
    @foreach ($data as $user)
        <form action="updateaccount" method="post">
          @csrf
         <tr>
            <td style="width:80px"><input type="hidden" name="id" value="{{ $user->id}}">  {{ $user->id }}</td>
            
            <td style="width:200px ;color:Black ;font-size:16px;background-color:Orange">  Edit Name: <input type="text" name="Name" value="{{ $user->Name }}" placeholder="Edit Name"> Name:{{ $user->Name }}</td>
            <td style="width:300px;color:Black ;font-size:16px;background-color:Orange">Edit Email:<input type="text" name="Email" value="{{ $user->Email }}" placeholder="Edit Email"> Email:{{ $user->Email }}</td>
            <td style="width:200px;color:Black ;font-size:16px;background-color:Orange">Edit Passward: <input type="text" name="Passward" value="{{ $user->Passward }}" placeholder="Edit Passward">Passward: {{ $user->Passward }}</td>
            <td style="width:200px;text-align:center ;background-color:Orange"><button type="submit">Edit</button>/
			<button><a href='delete/{{ $user->id }}'>Delete</a></button></td>
         </tr>
         </form>
         @endforeach
      </table>
     

</div>
</div>
        </body>
    </html>
  

