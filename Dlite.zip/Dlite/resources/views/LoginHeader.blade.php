<!DOCTYPE html>
<html>
<head>
<title>Dlite Shopping </title>
<!--/tags -->
<!-- <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script> -->
<!--//tags -->
<link rel="stylesheet" href="{{ URL::asset('css/bootstrap.css') }}" />

<link rel="stylesheet" href="{{ URL::asset('css/style.css') }}" />
<link rel="stylesheet" href="{{ URL::asset('css/font-awesome.css') }}" />
<link rel="stylesheet" href="{{ URL::asset('css/easy-responsive-tabs.css') }}" />
<link rel="stylesheet" href="{{ URL::asset('css/dropdown.css') }}" />
<!-- //for bootstrap working -->
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>


</head>
<body>
<!-- header -->
<div class="header" id="home">
	<div class="container">
		<ul>
			<li></li>
			<li></li>
			
		   <li> <a href="" data-toggle="modal" data-target="#myModal"><i class="fa fa-unlock-alt" aria-hidden="true"></i> </a></li>
			<li> <a href="{{('signup')}}" data-toggle="modal" data-target="#myModal2"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>LogOut </a></li>
			
		
		</ul>
	</div>
</div>
<!-- //header -->
<!-- header-bot -->
<div class="header-bot">
	<div class="header-bot_inner_wthreeinfo_header_mid">
		<div class="col-md-4 header-middle">
			<form action="#" method="post">
					<input type="search" name="search" placeholder="Search here..." required="">
					<button style="height:45px; width:45px;"> <i><img src="{{URL::asset('/photos/Search.png')}}" alt="profile Pic" style="height:30px; width:30px"></i>
				    </button>
					
					<div class="clearfix">
															  
				</div>
			</form>
		</div>
		<!-- header-bot -->
			<div class="col-md-4 logo_agile">
				<h1><a href="index.html"><span></span> Dlite <span>Shopping</span> <i class="fa fa-shopping-bag top_logo_agile_bag" aria-hidden="true"></i></a></h1>
			</div>
        <!-- header-bot -->
		<div class="col-md-4 agileits-social top_content">
						<ul class="social-nav model-3d-0 footer-social w3_agile_social">
						                                   <li class="share">Share On : </li>
															<li><a href="#" class="">
																  <div class="front"><i class="" aria-hidden="true">
																  <img src="{{URL::asset('/photos/Google.jpg')}}" alt="profile Pic" style="height:30px; width:30px">
																  </i></div>
																  <div class="back"><i class="" aria-hidden="true">
																  <img src="{{URL::asset('/photos/Google.jpg')}}" alt="profile Pic" style="height:30px; width:30px">
																  </i></div>
																  
																</a></li>
																
																  <li><a href="#" class=""> 
																  <div class="front"><i class="" aria-hidden="true">
																	  <img src="{{URL::asset('/photos/facebook.png')}}" alt="profile Pic" style="height:30px; width:30px"></i>
																  
																</div>
																  <div class="back"><i class="" aria-hidden="true">
																  <img src="{{URL::asset('/photos/facebook.png')}}" alt="profile Pic" style="height:30px; width:30px">
																  </i></div></a></li>
															<li><a href="#" class="">
																  <div class="front"><i class="" aria-hidden="true">
																	  
																  <img src="{{URL::asset('/photos/Instragram.png')}}" alt="profile Pic" style="height:30px; width:30px">
																  </i></div>
																  <div class="back"><i class="" aria-hidden="true">
																  <img src="{{URL::asset('/photos/Instragram.png')}}" alt="profile Pic" style="height:30px; width:30px">
																  </i></div></a></li>
															<li><a href="#" class="">
																  <div class="front"><i class="" aria-hidden="true">
																	  
																  <img src="{{URL::asset('/photos/Twitter.png')}}" alt="profile Pic" style="height:30px; width:30px">
																  </i></div>
																  <div class="back"><i class="" aria-hidden="true">
																  <img src="{{URL::asset('/photos/Twitter.png')}}" alt="profile Pic" style="height:30px; width:30px">
																  </i></div></a></li>
														</ul>



		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!-- banner -->
<div class="ban-top">
	<div class="container">
		<div class="top_nav_left">
			<nav class="navbar navbar-default">
			  <div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<!-- <div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div> -->
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse menu--shylock" id="bs-example-navbar-collapse-1">
				  <ul class="nav navbar-nav menu__list">
					<li class="active menu__item menu__item--current"><a class="menu__link" href="{{url('home')}}">Home <span class="sr-only">(current)</span></a></li>
					<li class=" menu__item"><a class="menu__link" href="{{url('about')}}">About</a></li>
					<li class="dropdown menu__item">
						<a href="#" class="dropdown-toggle menu__link dropdown " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">	

  Mens Wears <span class="caret"></span>
  <div class="dropdown-content">
    
											<a href="{{('mencloth')}}">Clothing</a>
											<a href="{{('menwallet')}}">Wallets</a>
											<a href="{{('menfootwear')}}">Footwear</a>
											<a href="{{('menwatch')}}">Watches</a>
											<a href="{{('menbag')}}">Bags</a>
											<a href="{{('menjewellery')}}">Jewellery</a>
											<a href="{{('mensunglasses')}}">Sunglasses</a>
											<a href="{{('menperfume')}}">Perfumes</a>
 </div> </a>
						
 
					</li>
					<li class="dropdown menu__item">
						<a href="#" class="dropdown-toggle menu__link dropdown " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">	

  Women Wears <span class="caret"></span>
  <div class="dropdown-content">
    
                                            <a href="{{('womencloth')}}">Clothing</a>
											<a href="{{('womenwallet')}}">Wallets</a>
											<a href="{{('womenfootwear')}}">Footwear</a>
											<a href="{{('womenwatch')}}">Watches</a>
											<a href="{{('womenbag')}}">Bags</a>
											<a href="{{('womenjwellery')}}">Jewellery</a>
											<a href="{{('womensunglasses')}}">Sunglasses</a>
											<a href="{{('womenperfume')}}">Perfumes</a>
 </div> </a>
						

					</li>
					<li class="dropdown menu__item">
						<a href="#" class="dropdown-toggle menu__link dropdown " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">	

  Kids <span class="caret"></span>
  <div class="dropdown-content">
    
											<a href="">Clothing</a>
											<a href="womens.html">Wallets</a>
											<a href="womens.html">Footwear</a>
											<a href="womens.html">Watches</a>
											<a href="womens.html">Bags</a>
											<a href="womens.html">Jewellery</a>
											<a href="womens.html">Sunglasses</a>
											<a href="womens.html">Perfumes</a>
 </div> </a>
						

					</li>
					<li class=" menu__item"><a class="menu__link" href="{{url('contact')}}">Contact</a></li>
				  </ul>
				</div>
			  </div>
			</nav>	
		</div>
		<div class="top_nav_right">
			<div class="wthreecartaits wthreecartaits2 cart cart box_1"> 
						<form action="#" method="post" class="last"> 
						<input type="hidden" name="cmd" value="_cart">
						<input type="hidden" name="display" value="1">
						<button class="" type="submit" name="submit" value=""><i><img src="{{URL::asset('/photos/cart.png')}}" alt="profile Pic" style="height:45px; width:45px"></i>
				</button>
					</form>  
  
						</div>
		</div>
		
		<div class="clearfix"></div>
	</div>
	
</div>
