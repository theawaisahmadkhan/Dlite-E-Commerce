<html>
        <head>
            <title>Edit Products</title>
            <style>
                table, th, td {
  border: 1px solid black;
}
            </style>
        </head>
        <body>
        <div>
        <header style="height:100px;width:117%;border:1px solid black;background-color:Orange">

<!-- <div> <img style="height:100px;width:40%;"src="{{URL::asset('/photos/delite.jpg')}}" alt=""></div> -->
<h1 style="text-align:center;font-size:60px;vertical-align: text-top; text-shadow: 2px 2px white;">Dlite Shopping</h1>
</header>
<aside style="width:200px;height:100%; border:1px solid black">
<div ><button style="height:10%;width:100%;background-color:Orange;"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;" href="{{('admin')}}">  Dashboard</a></button></div>
<div ><button style="height:10%;width:100%;"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;"href="{{('sales')}}">Sales</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;;text-shadow: 2px 2px black;"href="{{('chat')}}">Chats</a> </button></div>
<div ><button style="height:10%;width:100%"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;" href="{{('data')}}">Account</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;"href="{{('addproduct')}}">Add Product</a> </button></div>
<div ><button style="height:10%;width:100%"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;"href="{{('editproduct')}}">Edit Product</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;"href="{{('orderdata')}}">Orders</a> </button></div>

</aside>
<!-- section part where thing will be shown -->
<div style="position: absolute; top:120px; left:220px;border:1px solid black;width:100%;">


<table>
  <tr>
    <th style="width:20%">Image</th>
    <th style="width:15%">Product Name</th>
    <th style="width:15%">Discount</th>
    <th style="width:15%">Quantity</th>
    <th style="width:12%">Price</th>
    <th style="width:8%">Category</th>
    <th style="width:10%">SubCategory</th>
    <th style="width 10%">Edit/Delete</th>
  </tr>
</table>
    
@if(session('status'))
        <h2 style="text-align:center" class="alert alert Success">{{session('status')}}</h2>
        @endif
         @foreach ($data as $Product)
         <form action="updateproduct" method="post" enctype="multipart/form-data">
             @csrf
             <input type="hidden" name="id" value="{{ $Product->id}}">
         <table style="">
         <br>
         <tr>
            <td style="width:18%"><img style="width:80px;height:100px;" src="{{ asset('image/' . $Product->Image) }}" alt="Any alt text"/>
        <input type="file" name="Image" value="">
        </td>
            <td style="width:12%;color:Black ;font-size:16px;background-color:Orange">Edit Name:<input type="text" name="Name" value="{{ $Product->Name }}" placeholder="Edit Product Name">Name: {{ $Product->Name }}</td>
            <td style="width:12%;color:Black ;font-size:16px;background-color:Orange">Edit Discount: <input type="text" name="Discount" value="{{ $Product->Discount }}" placeholder="Edit Product Discount">Discount:{{ $Product->Discount }}</td>
            <td style="width:12%;color:Black ;font-size:16px;background-color:Orange">Edit Quantity<input type="text" name="Quantity" value="{{ $Product->Quantity }}" placeholder="Edit Product Quantity">Quantity:{{ $Product->Quantity }}</td>
            <td style="width:12%;color:Black ;font-size:16px;background-color:Orange">Edit Price<input type="text" name="Price" value="{{ $Product->Price }}" placeholder="Edit Product Price">Price:{{ $Product->Price }}</td>
            <td style="width:8%;color:Black ;font-size:16px;background-color:Orange"> Edit Category:
                <select name="product_categorie" value="{{ $Product->Category }}">
       <option value="Men">Men</option>
       <option  value="Women">Women</option>
       <option  value="Kid">Kid</option>
    </select>{{ $Product->Category }}</td>

        <td style="width:10%;color:Black ;font-size:16px;background-color:Orange"> Edit SubCategory<select name="product_subcategorie" value="{{ $Product->SubCategory }}">
         <option   value="Cloths">Cloths</option>
         <option value="Shoes">Shoes</option>
         <option value="Watches">Watches</option>
         <option value="Bag">Bag</option>
         <option value="Jewelllery">Jewellery</option>
         <option value="Perfume">Perfume</option>
         <option value="Wallet">Wallet</option>
         <option value="Glasses">Glasses</option>
         </select>{{ $Product->SubCategory }}</td>
            <td style="width:10%;text-align:center;color:Black ;font-size:16px;background-color:Orange"><button type="submit">Edit</button>/
            <button><a href='deleteproduct/{{ $Product->id }}'>Delete</a></button>
			</td>
         </tr>
        
         </table>
         </form>
         @endforeach
     

</div>
</div>
        </body>
    </html>
  

