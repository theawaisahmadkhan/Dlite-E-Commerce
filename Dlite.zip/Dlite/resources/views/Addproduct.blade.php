<html>
    <head>
<title>Add Products</title>
    </head>
    <body>
   
    <div>
    <header style="height:100px;width:102%;border:1px solid black;background-color:Orange">

<!-- <div> <img style="height:100px;width:40%;"src="{{URL::asset('/photos/delite.jpg')}}" alt=""></div> -->
<h1 style="text-align:center;font-size:60px;vertical-align: text-top; text-shadow: 2px 2px white;">Dlite Shopping</h1>
</header>
<aside style="width:200px;height:100%; border:1px solid black">
<div ><button style="height:10%;width:100%;background-color:Orange;"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;" href="{{('admin')}}">  Dashboard</a></button></div>
<div ><button style="height:10%;width:100%;"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;"href="{{('sales')}}">Sales</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;;text-shadow: 2px 2px black;"href="{{('chat')}}">Chats</a> </button></div>
<div ><button style="height:10%;width:100%"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;" href="{{('data')}}">Account</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;"href="{{('addproduct')}}">Add Product</a> </button></div>
<div ><button style="height:10%;width:100%"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;"href="{{('editproduct')}}">Edit Product</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;"href="{{('orderdata')}}">Orders</a> </button></div>

</aside>

<!-- section part where thing will be shown -->
<div style="position: absolute; top:120px; left:220px;border:1px solid black;width:85%;">
@if(session('status'))
        <h2 style="text-align:center" class="alert alert Success">{{session('status')}}</h2>
        @endif
<section>
        
<form action="submitproduct" method="post" enctype="multipart/form-data">
    @csrf
<fieldset>

<!-- Form Name -->
<legend>PRODUCTS</legend>

<!-- Text input-->
<div >
  <label >PRODUCT ID</label>  
  <div >
  <input  name="product_id" placeholder="PRODUCT ID"  required="" type="text">
    
  </div>
</div>
<br>
<!-- Text input-->
<div>
  <label >PRODUCT NAME</label>  
  <div>
  <input id="product_name" name="product_name" placeholder="PRODUCT NAME" required="" type="text">
    
  </div>
</div>
<br>


<!-- Select Basic -->
<div>
  <label >PRODUCT CATEGORY</label>
  <div >
    <select name="product_categorie">
       <option value="Men">Men</option>
       <option  value="Women">Women</option>
       <option  value="Kid">Kid</option>
    </select>
  </div>
</div>
<br>
<div>
    <label >PRODUCT SUB-CATEGORY</label>
    <div >
      <select name="product_subcategorie">
         <option   value="Cloths">Cloths</option>
         <option value="Shoes">Shoes</option>
         <option value="Watches">Watches</option>
         <option value="Bag">Bag</option>
         <option value="Jewelllery">Jewellery</option>
         <option value="Perfume">Perfume</option>
         <option value="Wallet">Wallet</option>
         <option value="Glasses">Glasses</option>
      </select>
    </div>
  </div>
  <br>
  <div>
  <label >SIZE</label>
  <div >
    <select name="size">
       <option value="Small">Small</option>
       <option  value="Medium">Medium</option>
       <option  value="Large">Large</option>
       <option  value="XL">XL</option>
       <option  value="XXL">XXL</option>
    </select>
  </div>
</div>
<br>
<!-- Text input-->
<div >
  <label>AVAILABLE QUANTITY</label>  
  <div >
  <input name="available_quantity" placeholder="AVAILABLE QUANTITY" required="" type="text">
    
  </div>
</div>
<br>
<!-- Text input-->


<!-- Textarea -->
<div >
  <label  >PRODUCT DESCRIPTION</label>
  <div >                     
    <textarea  id="product_description" name="product_description"></textarea>
  </div>
</div><br>

<!-- Textarea -->


<!-- Text input-->
<div >
  <label>PERCENTAGE DISCOUNT</label>  
  <div >
  <input  name="discount" placeholder="PERCENTAGE DISCOUNT"  required="" type="text">
    
  </div>
</div>
<br>
<!-- Text input-->


<!-- Text input-->
<div >
  <label >BRAND</label>  
  <div >
  <input name="brand" placeholder="BRAND"  required="" type="text">
    
  </div>
</div>



<br>
<div >
  <label >PRICE</label>  
  <div >
  <input name="Price" placeholder="PRICE"  required="" type="text">
    
  </div>
</div>
<br>
 <!-- File Button --> 
<div >
  <label >PRODUCT IMAGE</label>
  <div >
    <input  name="Image"  type="file">
  </div>
</div>

<br>
<!-- Button -->
<div>
  <label >Single Button</label>
  <div >
    <button  type="submit" >Submit</button>
    <button  name="singlebutton" >
        <a href="{{('admin')}}">  DashBoard</a>
      </button>
  </div>
  </div>

</fieldset>
</form>

</section>
</div>
</div>
    

    </body>
</html>

