<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Users;
use App\Models\OrderCart;
use DB;
class Dashboard extends Controller
{
    function Dashboardretrive()
    {
        $data=DB::select('select *from users');
        $data1=DB::select('SELECT * FROM `order`');

        $users=0;
        $orders=0;
        $sales=0;

        foreach($data as $user)
        {
            $users++;
        }
           
        
        foreach($data1 as $o)
        {
            if($o->Status=='pending')
            {
                $orders++;
            }
            else{
                $sales++;
            }
        }
        //  print($users);
        //  print($orders);
        //  print($sales);
        return view('admin',['users'=>$users,'orders'=>$orders,'sales'=>$sales]);
       
       
    }
    public function Salesretrive()
    {
        $data=DB::select('SELECT * FROM `order`');
        // $d=DB::Select('select *from order ');
     //    print_r($data);
     //    print_r($data);
         return view('Sales',['data'=>$data]);
    }
    
}
