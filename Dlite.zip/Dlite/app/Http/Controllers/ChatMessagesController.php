<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Chat;
use DB;
class ChatMessagesController extends Controller
{
    public function  store(Request $req)
    {
       $data=new Chat;
       $data->Name=$req->Name;
       $data->Email=$req->Email;
       $data->Messsage=$req->Message;
       $data->save();
       
return redirect()->back()->with('status','Message Delived');

    }
    public function retrive()
    {
         $data=DB::select('select *from chatmessages');
         return view('chat',['data'=>$data]);
    }
    public function destroy($id)
    {
        Db::delete('delete from chatmessages where id=?',[$id]);
        return redirect()->back()->with('status','Message Successfully Deleted');
    }
}
