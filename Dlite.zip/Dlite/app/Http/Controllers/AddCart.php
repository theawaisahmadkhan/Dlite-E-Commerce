<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cart;
use App\Models\Users;
use Storage;
use DB;
class AddCart extends Controller
{
    function store(Request $req)
    {
        if($req->Userid==0)
        {
            return redirect()->back()->with('status','Please Login for cart');
        }
        else{
            $cart=new Cart;
            print_r($req->input());
            $cart->Userid=$req->Userid;
            $cart->Name=$req->name;
            $cart->Category=$req->Category;
            $cart->SubCategory=$req->SubCategory;
            $cart->Price=$req->price;
            $cart->size=$req->size;
            
            $cart->Image=$req->Image;
            $cart->Brand=$req->Brand;
            $cart->Discount=$req->Discount;
            
            $cart->save();
            return redirect()->back()->with('status','Successfully Added in Your Cart');
        }
      
    }
    public function cartretrive()
    {
        $id=Storage::get('file.txt');
         $this->userid=$id;
        //  print_r($id);
        //$data =DB::select('select *from cart where id=?',[$id]);
        $data=Cart::where('userid',$id)->get();
        // $data=DB::select('select *from cart');
         
        // print_r($data);
         
         return view('Cart',['data'=>$data,
        'loginid'=>$id]);
    }
    public function destroy($id)
    {
       
        DB::delete('DELETE FROM cart WHERE id=?',[$id]);
        return redirect()->back()->with('status','Cart Product Successfully Deleted');
    }
}
