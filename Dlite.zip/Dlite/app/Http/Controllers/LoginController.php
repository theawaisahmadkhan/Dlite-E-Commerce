<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Signup;
use App\Models\Addproduct;
use DB;
use Storage;
use resources\views\master;

class LoginController extends Controller
{
   
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function retrive(Request $req)
    {
        $data=DB::select('select *from users  ');
       $check=0;
        foreach ($data as $user){
            
            if($user->Email===$req->Email)
            {
              
               //print_r($data);
                if($user->Passward===$req->Passward)
                {
                    if($user->Email=='awaisahmadlist@gmail.com')
                    {
                        if($user->Passward=='admin1122')
                        {
                            return view('admin');
                            $check=1;
                        }
                        else{
                          
                            return redirect()->back()->with('status','Wrong Passward or UserName');
                            
                            }
                       
                    }
                    else{
                          
                      
                         Storage::put('file.txt', $user->id);
                        
                         $this->userid=$user->id;
                        $data=DB::select('select *from product  ');
                       
                        
                       $check=1;
                        return view('LoginWelcome',[
                            'data'=>$data,
                            'loginid'=>$this->userid
                        
                        ]);
                        
                        }
                   
                }
            }
        }
        
       if($check==0)
       {
        return redirect()->back()->with('status','Wrong Passward or UserName');
       }
        
    }
    public function retrive1(){
        $data=DB::select('select *from users ');
        // return view('show',['users'=>$data]);
        return view('account',['data'=>$data]);
       // print_r($data);
    }

    public function updateaccount(Request $req){
       
        $p = Signup::find($req->id);
        print_r($req->input());
        $p->Name = $req->Name;
        $p->Email= $req->Email;
        $p->Passward= $req->Passward;
        $p->update();
        
return redirect()->back()->with('status','Account Updated Successfully');


    }
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    function save(Request $req)
    {
        print_r($req->input());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
