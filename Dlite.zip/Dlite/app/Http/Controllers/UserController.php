<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Users;
class UserController extends Controller
{
    function save(Request $req)
    {
        $u=new Users;//object of Model
        //$u->id='2';this is autoincrement id
        $u->Name=$req->Name;
        $u->Email=$req->Email;
        $u->Passward=$req->passward;
        $u->save();
        print_r($req->input());

    }
    
}

