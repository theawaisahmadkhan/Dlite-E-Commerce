<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\OrderCart;
use App\Models\Users;

use DB;
class Orderfullfill extends Controller
{
    public function getorder(Request $req)
    {
         $data=new OrderCart;
        $p = Users::find($req->Userid);
      


        $data->UserName=$p->Name;
        $data->ProductId=$req->id;
        $data->ProductName=$req->Name;
        $data->Category=$req->Category;
        $data->SubCategory=$req->SubCategory;
        $data->Price=$req->Price;
        $data->Quantity=$req->Quantity;
        $data->Image=$req->Image;
        $data->Brand=$req->Brand;
        $data->Discount=$req->Discount;
        $data->Status='pending';
        $data->save();
        
return redirect()->back()->with('status','We Have Recieved Your Order');
        
    }

    public function updateorder($id)
    {

        $p=OrderCart::find($id);
        $p->Status='Done';
        $p->update();
        return redirect()->back()->with('status','Order Confrom ');
    }
    public function getdata()
    {
        $data=DB::select('SELECT * FROM `order`');
       // $d=DB::Select('select *from order ');
    //    print_r($data);
    //    print_r($data);
        return view('Orderlist',['data'=>$data]);
    }
    public function destroy($id)
    {
         DB::delete('delete from `order` where id=?',[$id]);
         
return redirect()->back()->with('status','Order Successfully Deleted');
    }
}
