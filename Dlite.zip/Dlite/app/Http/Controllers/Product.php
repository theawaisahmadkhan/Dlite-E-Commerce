<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Addproduct;
use DB;
use Storage;
class Product extends Controller
{
    function addproduct(Request $req)
    {
         
        //  print_r($req->input());
         $product=new Addproduct;
        // $product->id=$req->product_id;
         //print_r($product->Id);
         $product->Name=$req->product_name;
         //print_r($product->Name);
         $product->Description=$req->product_description;
         //print_r($product->Description);
         $product->Category=$req->product_categorie;
         //print_r($product->Category);
         $product->SubCategory=$req->product_subcategorie;
         //print_r($product->SubCategory);
         $product->Price=$req->Price;
         $product->size=$req->size;
         //print_r($product->Price);
         $product->Quantity=$req->available_quantity;
         //print_r($product->Quantity);
        
       
         if($req->hasfile('Image'))
         {
$file=$req->file('Image');
$extention=$file->getClientOriginalExtension();
 $filename=time().'.'.$extention;
$file->move('image',$filename);
$product->Image=$filename;

     }
       // $req->file('Image')->save('public/image');

       
    
          // $name = $req->file('Image')->getClientOriginalName();
    
        //    $req->file('Image')->move('public/image');
    
        // print_r($product->Image);
        $product->Brand=$req->brand;
         $product->Discount=$req->discount;
         $product->save();
         
return redirect()->back()->with('status','Product Added Successfully');
         //print_r($product->Discount);
      
    }
    public function destroy($id)
    {
        DB::delete('DELETE FROM  product WHERE id=?',[$id]);
return redirect()->back()->with('status','Product Successfully Deleted');
    }

   
    public function updateproduct(Request $req)
    {
      
      $p = Addproduct::find($req->id);
        $f=$req->Image;
      if($req->Image!=null)
      {

         if( $req->hasfile('Image'))
         {

          $file=$req->file('Image');
          $extention=$file->getClientOriginalExtension();
          $filename=time().'.'.$extention;
          $file->move('image',$filename);
          $p->Image=$filename;
          
        //  print_r($req->input());

         }
         
        
       $p->Name = $req->Name;
       $p->Discount= $req->Discount;
       $p->Quantity= $req->Quantity;
       $p->Price= $req->Price;
       $p->Category= $req->product_categorie;
       $p->SubCategory= $req->product_subcategorie;
       print_r($req->input());
       print_r($req->input());
        $p->update();
        
return redirect()->back()->with('status','Product Updated Successfully');
      }
      
      
        else{

          $p->Name = $req->Name;
          $p->Discount= $req->Discount;
          $p->Quantity= $req->Quantity;
          $p->Price= $req->Price;
          $p->Category= $req->product_categorie;
          $p->SubCategory= $req->product_subcategorie;
          
           $p->update();
           
        
return redirect()->back()->with('status','Product Updated Successfully');
        }
         


    

   

      
    }
   

    public function retriveproductforedit(){
      $data=DB::select('select *from product ');
      
      return view('EditProduct',['data'=>$data]);
    
  }

    public function retrive(){
        $data=DB::select('select *from product ');
        
        return view('Men\Cloth',['data'=>$data,
        'loginid'=>$this->userid]);
      
    }
    public function retrive1(){
      $data=DB::select('select *from product ');
      Storage::put('file.txt', 0);
      return view('master',['data'=>$data,
      'loginid'=>$this->userid
    ]);
     // print_r($data);
  }
  public function mencloth(){
    $data=DB::select('select *from product ');
    $content=Storage::get('file.txt');
               
    $this->userid=$content;
    return view('Men\Cloth',['data'=>$data,
    'loginid'=>$this->userid]);
   
}
public function menshoes(){
  $data=DB::select('select *from product ');
  $content=Storage::get('file.txt');
             
  $this->userid=$content;
  return view('Men\Footwear',['data'=>$data,
  'loginid'=>$this->userid]);
 
}
public function menbag(){
  $data=DB::select('select *from product ');
  $content=Storage::get('file.txt');
             
  $this->userid=$content;
  return view('Men\bag',['data'=>$data,
  'loginid'=>$this->userid]);
 
}

public function menwallet(){
  $data=DB::select('select *from product ');
  $content=Storage::get('file.txt');
             
  $this->userid=$content;
  return view('Men\Wallet',['data'=>$data,
  'loginid'=>$this->userid]);
 
}
public function menjewellery(){
  $data=DB::select('select *from product ');
  $content=Storage::get('file.txt');
             
  $this->userid=$content;
  return view('Men\jewellery',['data'=>$data,
  'loginid'=>$this->userid]);
 
}
public function menperfume(){
  $data=DB::select('select *from product ');
  $content=Storage::get('file.txt');
             
  $this->userid=$content;
  return view('Men\perfume',['data'=>$data,
  'loginid'=>$this->userid]);
 
}

public function mensunglasses(){
  $data=DB::select('select *from product ');
  $content=Storage::get('file.txt');
             
  $this->userid=$content;
  return view('Men\sunglasses',['data'=>$data,
  'loginid'=>$this->userid]);
 
}
public function menwatch(){
  $data=DB::select('select *from product ');
  $content=Storage::get('file.txt');
             
  $this->userid=$content;
  return view('Men\Watch',['data'=>$data,
  'loginid'=>$this->userid]);
 
}


//Women
public function womencloth(){
  $data=DB::select('select *from product ');
  $content=Storage::get('file.txt');
             
  $this->userid=$content;
  return view('Women\Cloth',['data'=>$data,
  'loginid'=>$this->userid]);
 
}
public function womenfootwear(){
$data=DB::select('select *from product ');
$content=Storage::get('file.txt');
           
$this->userid=$content;
return view('Women\Footwear',['data'=>$data,
'loginid'=>$this->userid]);

}
public function womenbag(){
$data=DB::select('select *from product ');
$content=Storage::get('file.txt');
           
$this->userid=$content;
return view('Women\bag',['data'=>$data,
'loginid'=>$this->userid]);

}

public function womenwallet(){
$data=DB::select('select *from product ');
$content=Storage::get('file.txt');
           
$this->userid=$content;
return view('Women\Wallet',['data'=>$data,
'loginid'=>$this->userid]);

}
public function womenjewellery(){
$data=DB::select('select *from product ');
$content=Storage::get('file.txt');
           
$this->userid=$content;
return view('Women\jewellery',['data'=>$data,
'loginid'=>$this->userid]);

}
public function womenperfume(){
$data=DB::select('select *from product ');
$content=Storage::get('file.txt');
           
$this->userid=$content;
return view('Women\perfume',['data'=>$data,
'loginid'=>$this->userid]);

}

public function womensunglasses(){
$data=DB::select('select *from product ');
$content=Storage::get('file.txt');
           
$this->userid=$content;
return view('Women\sunglasses',['data'=>$data,
'loginid'=>$this->userid]);

}
public function womenwatch(){
$data=DB::select('select *from product ');
$content=Storage::get('file.txt');
           
$this->userid=$content;
return view('Women\Watch',['data'=>$data,
'loginid'=>$this->userid]);

}

//kids

public function kidcloth(){
  $data=DB::select('select *from product ');
  $content=Storage::get('file.txt');
             
  $this->userid=$content;
  return view('Kid\Cloth',['data'=>$data,
  'loginid'=>$this->userid]);
 
}
public function kidfootwear(){
$data=DB::select('select *from product ');
$content=Storage::get('file.txt');
           
$this->userid=$content;
return view('Kid\Footwear',['data'=>$data,
'loginid'=>$this->userid]);

}
public function kidbag(){
$data=DB::select('select *from product ');
$content=Storage::get('file.txt');
           
$this->userid=$content;
return view('Kid\bag',['data'=>$data,
'loginid'=>$this->userid]);

}

public function kidwallet(){
$data=DB::select('select *from product ');
$content=Storage::get('file.txt');
           
$this->userid=$content;
return view('Kid\Wallet',['data'=>$data,
'loginid'=>$this->userid]);

}
public function kidjewellery(){
$data=DB::select('select *from product ');
$content=Storage::get('file.txt');
           
$this->userid=$content;
return view('Kid\jewellery',['data'=>$data,
'loginid'=>$this->userid]);

}
public function kidperfume(){
$data=DB::select('select *from product ');
$content=Storage::get('file.txt');
           
$this->userid=$content;
return view('Kid\perfume',['data'=>$data,
'loginid'=>$this->userid]);

}

public function kidsunglasses(){
$data=DB::select('select *from product ');
$content=Storage::get('file.txt');
           
$this->userid=$content;
return view('Kid\sunglasses',['data'=>$data,
'loginid'=>$this->userid]);

}
public function kidwatch(){
$data=DB::select('select *from product ');
$content=Storage::get('file.txt');
           
$this->userid=$content;
return view('Kid\Watch',['data'=>$data,
'loginid'=>$this->userid]);

}
}
