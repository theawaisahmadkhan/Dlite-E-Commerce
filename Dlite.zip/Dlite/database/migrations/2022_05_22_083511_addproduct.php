<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Addproduct extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Product', function (Blueprint $table) {
            $table->id();
            $table->string('Name');
            $table->string('Description');
            $table->string('Category');
            $table->string('SubCategory');
            $table->string('Price');
            $table->string('size');
            $table->string('Quantity');
            $table->string('Image');
            $table->string('Brand');
            $table->string('Discount');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
