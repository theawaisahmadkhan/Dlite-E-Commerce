-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2022 at 07:34 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Userid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SubCategory` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Brand` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `Userid`, `Name`, `Category`, `SubCategory`, `Price`, `size`, `Image`, `Brand`, `Discount`, `created_at`, `updated_at`) VALUES
(1, '0', 'kasjdh', 'Men', 'Cloths', 'asd', 'Small', '1653208666.jpg', 'asd', 'asd', '2022-05-22 07:34:58', '2022-05-22 07:34:58'),
(3, '5', 'Shirt', 'Men', 'Cloths', '3000', 'Large', '1653288196.jpeg', 'gulahmand', '2', '2022-05-23 02:17:11', '2022-05-23 02:17:11'),
(4, '5', 'Shirt', 'Men', 'Cloths', '3000', 'Large', '1653288196.jpeg', 'gulahmand', '2', '2022-05-23 06:49:58', '2022-05-23 06:49:58'),
(5, '7', 'Salwar Kameez', 'Men', 'Cloths', '7000', 'Large', '1653327475.jpeg', 'Gulahmad', '0', '2022-05-23 13:57:25', '2022-05-23 13:57:25'),
(6, '7', 'Bag', 'Men', 'Bag', '5000', 'Large', '1653328208.jpg', 'Pakistan-Bag', '0', '2022-05-23 13:57:38', '2022-05-23 13:57:38'),
(7, '7', 'Wrist Watch', 'Men', 'Watches', '45000', 'Large', '1653327850.jpg', 'Rado', '0', '2022-05-23 13:57:47', '2022-05-23 13:57:47');

-- --------------------------------------------------------

--
-- Table structure for table `chatmessages`
--

CREATE TABLE `chatmessages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Messsage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chatmessages`
--

INSERT INTO `chatmessages` (`id`, `Name`, `Email`, `Messsage`, `created_at`, `updated_at`) VALUES
(2, 'Awais', 'umairahmad@gmaiil.com', 'Hello', '2022-05-24 02:59:38', '2022-05-24 02:59:38'),
(3, 'Awais', 'awaisahamd21@gmail.com', 'Hello', '2022-05-24 03:00:24', '2022-05-24 03:00:24');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2022_05_07_171939_create_users_table', 1),
(3, '2022_05_17_180048_product', 2),
(4, '2022_05_17_181639_product', 3),
(5, '2022_05_18_115215_addproduct', 4),
(6, '2022_05_19_162021_order', 5),
(7, '2022_05_22_083511_addproduct', 6),
(8, '2022_05_22_114053_add_cart', 7),
(9, '2022_05_24_072255_chat_messages', 8);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `UserName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ProductId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ProductName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SubCategory` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Brand` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `UserName`, `ProductId`, `ProductName`, `Category`, `SubCategory`, `Price`, `Quantity`, `Image`, `Brand`, `Discount`, `Status`, `created_at`, `updated_at`) VALUES
(4, 'Awais', '5', 'Salwar Kameez', 'Men', 'Cloths', '7000', '2', '1653327475.jpeg', 'Gulahmad', '0', 'pending', '2022-05-24 03:12:10', '2022-05-24 03:12:10');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SubCategory` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Brand` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Discount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `Name`, `Description`, `Category`, `SubCategory`, `Price`, `size`, `Quantity`, `Image`, `Brand`, `Discount`, `created_at`, `updated_at`) VALUES
(2, 'Shirt', 'men', 'Men', 'Cloths', '3000', 'Small', '20', '1653283504.jpg', 'asd', '20', '2022-05-22 12:45:29', '2022-05-23 10:45:51'),
(4, 'Shirt', 'Young Shirt', 'Men', 'Cloths', '3000', 'Large', '10', '1653288196.jpeg', 'gulahmand', '2', '2022-05-23 01:43:16', '2022-05-23 01:43:16'),
(6, 'Salwar Kameez', 'Men\'s clothes are articles of clothing designed for and worn by men.', 'Men', 'Cloths', '7000', 'Large', '10', '1653327475.jpeg', 'Gulahmad', '0', '2022-05-23 12:37:55', '2022-05-23 12:37:55'),
(7, 'Salwar Kameez', 'Men\'s clothes are articles of clothing designed for and worn by men.', 'Men', 'Cloths', '5000', 'Medium', '10', '1653327513.webp', 'gulahmand', '2', '2022-05-23 12:38:33', '2022-05-23 12:38:33'),
(8, 'Nikkah Field', 'Men\'s clothes are articles of clothing designed for and worn by men.', 'Men', 'Cloths', '25000', 'Large', '10', '1653327583.jpg', 'Diners', '0', '2022-05-23 12:39:43', '2022-05-23 12:39:43'),
(9, 'Suite Coat', 'Men\'s clothes are articles of clothing designed for and worn by men.', 'Men', 'Cloths', '35000', 'Medium', '10', '1653327626.jpg', 'Diners', '0', '2022-05-23 12:40:26', '2022-05-23 12:40:26'),
(10, 'Suite Coat', 'Men\'s clothes are articles of clothing designed for and worn by men.', 'Men', 'Cloths', '45210', 'Large', '10', '1653327658.webp', 'Suitting', '0', '2022-05-23 12:40:58', '2022-05-23 12:40:58'),
(11, 'Suite Coat', 'Men\'s clothes are articles of clothing designed for and worn by men.', 'Men', 'Cloths', '12500', 'Large', '10', '1653327701.jpg', 'Diners', '2', '2022-05-23 12:41:41', '2022-05-23 12:41:41'),
(12, 'Suite Coat', 'Men\'s clothes are articles of clothing designed for and worn by men.', 'Men', 'Cloths', '25400', 'Medium', '10', '1653327732.webp', 'Diners', '10', '2022-05-23 12:42:12', '2022-05-23 12:42:12'),
(13, 'Wrist Watch', 'One for the traditional man. A mechanical watch is your original, old-fashioned, hand-wound watch', 'Men', 'Watches', '50000', 'Medium', '50', '1653327807.jpg', 'Rolex', '0', '2022-05-23 12:43:27', '2022-05-23 12:43:27'),
(14, 'Wrist Watch', 'One for the traditional man. A mechanical watch is your original, old-fashioned, hand-wound watch', 'Men', 'Watches', '45000', 'Large', '50', '1653327850.jpg', 'Rado', '0', '2022-05-23 12:44:10', '2022-05-23 12:44:10'),
(15, 'Men Perfume', 'Often these notes are bergamot, white musk and patchouli.', 'Men', 'Perfume', '12000', 'Medium', '10', '1653327916.jpeg', 'Mens', '0', '2022-05-23 12:45:16', '2022-05-23 12:45:16'),
(16, 'Perfume', 'Often these notes are bergamot, white musk and patchouli.', 'Men', 'Perfume', '25100', 'Small', '10', '1653327962.jpg', 'franco', '2', '2022-05-23 12:46:02', '2022-05-23 12:46:02'),
(17, 'Ring', 'Men Rising is an initiative that grew out of men around the world', 'Men', 'Jewelllery', '3500', 'Small', '10', '1653328056.jpg', 'Ring', '2', '2022-05-23 12:47:36', '2022-05-23 12:47:36'),
(18, 'Ring', 'Men Rising is an initiative that grew out of men around the world', 'Men', 'Jewelllery', '35210', 'Large', '50', '1653328098.jpg', 'Ring', '0', '2022-05-23 12:48:18', '2022-05-23 12:48:18'),
(19, 'Ring', 'Men Rising is an initiative that grew out of men around the world', 'Men', 'Jewelllery', '35120', 'Medium', '10', '1653328156.jpg', 'Ring', '10', '2022-05-23 12:49:16', '2022-05-23 12:49:16'),
(20, 'Bag', 'used to showcase wealth and overpower body odours', 'Men', 'Bag', '5000', 'Large', '10', '1653328208.jpg', 'Pakistan-Bag', '0', '2022-05-23 12:50:08', '2022-05-23 12:50:08'),
(21, 'Wallet', 'A wallet is a flat case', 'Men', 'Wallet', '4500', 'Medium', '50', '1653328277.jpg', 'Diner', '2', '2022-05-23 12:51:17', '2022-05-23 12:51:17'),
(22, 'Wallet', 'A wallet is a flat case', 'Men', 'Wallet', '6500', 'Small', '50', '1653328314.jpg', 'Diners', '0', '2022-05-23 12:51:54', '2022-05-23 12:51:54'),
(23, 'Suite-Shoes', 'Shoe to be worn at more formal events', 'Men', 'Shoes', '7500', 'Large', '10', '1653328383.jpg', 'Service', '2', '2022-05-23 12:53:03', '2022-05-23 12:53:03'),
(24, 'Suite-Shoes', 'Shoe to be worn at more formal events', 'Men', 'Shoes', '14500', 'Medium', '10', '1653328422.jpg', 'Diners', '0', '2022-05-23 12:53:42', '2022-05-23 12:53:42'),
(25, 'Suite-Shoes', 'Shoe to be worn at more formal events', 'Men', 'Shoes', '45200', 'Medium', '10', '1653328466.jpg', 'Diner', '2', '2022-05-23 12:54:26', '2022-05-23 12:54:26'),
(26, 'Glasses', 'Eyeglasses are constructed of several parts', 'Men', 'Glasses', '14000', 'Small', '10', '1653328526.jpg', 'Flipcart', '10', '2022-05-23 12:55:26', '2022-05-23 12:55:26'),
(27, 'Glasses', 'Eyeglasses are constructed of several parts', 'Men', 'Glasses', '1250', 'Medium', '50', '1653328568.webp', 'Fhonex', '2', '2022-05-23 12:56:08', '2022-05-23 12:56:08'),
(28, 'Salwar Suite', 'The salwar kameez is a traditional outfit worn by Punjabi women', 'Women', 'Cloths', '12500', 'Medium', '10', '1653329241.jpg', 'ZARA', '0', '2022-05-23 13:07:21', '2022-05-23 13:07:21'),
(29, 'Salwar Suite', 'The salwar kameez is a traditional outfit worn by Punjabi women', 'Women', 'Cloths', '15000', 'Medium', '50', '1653329277.jpg', 'ZARA', '2', '2022-05-23 13:07:57', '2022-05-23 13:07:57'),
(30, 'Salwar Suite', 'The salwar kameez is a traditional outfit worn by Punjabi women', 'Women', 'Cloths', '12500', 'Large', '10', '1653329316.jpg', 'ZARA', '10', '2022-05-23 13:08:36', '2022-05-23 13:08:36'),
(31, 'Trouser', 'item of clothing worn on the lower part of the body and covering both legs separately', 'Women', 'Cloths', '12000', 'Medium', '10', '1653329368.jpg', 'Livis', '2', '2022-05-23 13:09:28', '2022-05-23 13:09:28'),
(32, 'Trouser', 'item of clothing worn on the lower part of the body and covering both legs separately', 'Women', 'Cloths', '1500', 'Medium', '2', '1653329401.jpg', 'ZARA', '10', '2022-05-23 13:10:01', '2022-05-23 13:10:01'),
(33, 'Trouser', 'item of clothing worn on the lower part of the body and covering both legs separately', 'Women', 'Cloths', '15000', 'Medium', '10', '1653329433.jpg', 'ZARA', '0', '2022-05-23 13:10:33', '2022-05-23 13:10:33'),
(34, 'Salwar Suite', 'The salwar kameez is a traditional outfit worn by Punjabi women', 'Women', 'Cloths', '12500', 'Small', '10', '1653329470.webp', 'ZARA', '0', '2022-05-23 13:11:10', '2022-05-23 13:11:10'),
(35, 'Glasses', 'women\'s eyeglasses', 'Women', 'Glasses', '12500', 'Medium', '10', '1653329526.jpg', 'Flipcart', '0', '2022-05-23 13:12:06', '2022-05-23 13:12:06'),
(36, 'Neckless', 'A necklace is an article of jewellery that is worn around the neck', 'Women', 'Jewelllery', '1254000', 'Medium', '2', '1653329589.jpg', 'ZARA', '0', '2022-05-23 13:13:09', '2022-05-23 13:13:09'),
(37, 'Perfume', 'Woman by Ralph Lauren by Ralph Lauren is a Floral fragrance for women', 'Women', 'Perfume', '12540', 'Small', '10', '1653329662.png', 'Gucci', '2', '2022-05-23 13:14:22', '2022-05-23 13:14:22'),
(38, 'Bag', 'A handbag is more than just a sack to carry essentials', 'Women', 'Cloths', '25000', 'Small', '2', '1653329711.jpg', 'Hand', '0', '2022-05-23 13:15:11', '2022-05-23 13:15:11'),
(39, 'Wallet', 'A handbag is more than just a sack to carry essentials', 'Women', 'Wallet', '4500', 'Medium', '10', '1653329757.webp', 'ZARA', '2', '2022-05-23 13:15:57', '2022-05-23 13:15:57'),
(40, 'Sandle', 'Dress shoes for women are typically a more formal option', 'Women', 'Shoes', '12400', 'Medium', '10', '1653329818.webp', 'Diners', '2', '2022-05-23 13:16:58', '2022-05-23 13:16:58'),
(41, 'Sandle', 'Dress shoes for women are typically a more formal option', 'Women', 'Shoes', '45100', 'Medium', '10', '1653329861.webp', 'Sandle', '0', '2022-05-23 13:17:41', '2022-05-23 13:17:41'),
(42, 'Bag', 'A woman\'s handbag is an integral part of her outfit', 'Women', 'Bag', '45100', 'Small', '50', '1653330093.jpg', 'gucci', '2', '2022-05-23 13:21:33', '2022-05-23 13:21:33'),
(43, 'Women Watch', 'Active women-on-the-go have a tendency to favour these two types of watches', 'Women', 'Watches', '12500', 'Medium', '2', '1653330157.webp', 'zara', '2', '2022-05-23 13:22:37', '2022-05-23 13:22:37');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(20) UNSIGNED NOT NULL,
  `Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Passward` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `Name`, `Email`, `Passward`, `created_at`, `updated_at`) VALUES
(2, 'Admin', 'awaisahmadlist@gmail.com', 'admin1122', '2022-05-17 07:20:36', '2022-05-17 07:20:36'),
(5, 'Umair', 'umairahmad@gmail.com', 'umair', '2022-05-17 07:53:03', '2022-05-17 07:53:03'),
(7, 'Awais', 'awaisahamd21@gmail.com', 'awais', '2022-05-23 13:50:37', '2022-05-23 13:50:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chatmessages`
--
ALTER TABLE `chatmessages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `chatmessages`
--
ALTER TABLE `chatmessages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
