<!DOCTYPE html>
<html>
<head>
<title>Elite Shoppy an Ecommerce Online Shopping Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
<!--/tags -->
<!-- <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script> -->
<!--//tags -->
<link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(URL::asset('css/style.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(URL::asset('css/font-awesome.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(URL::asset('css/easy-responsive-tabs.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(URL::asset('css/dropdown.css')); ?>" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- //for bootstrap working -->
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>


</head>
<body>
<!-- header -->
<div class="header" id="home">
	<div class="container">
		<ul>
			<li></li>
			<li></li>
			
		   <li> <a href="<?php echo e(('login')); ?>" data-toggle="modal" data-target="#myModal"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Sign In </a></li>
			<li> <a href="<?php echo e(('signup')); ?>" data-toggle="modal" data-target="#myModal2"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Sign Up </a></li>
			
		
		</ul>
	</div>
</div>
<!-- //header -->
<!-- header-bot -->
<div class="header-bot">
	<div class="header-bot_inner_wthreeinfo_header_mid">
		<div class="col-md-4 header-middle">
			<form action="#" method="post">
					<input type="search" name="search" placeholder="Search here..." required="">
					<button style="height:45px; width:45px;"> <i><img src="<?php echo e(URL::asset('/photos/Search.png')); ?>" alt="profile Pic" style="height:30px; width:30px"></i>
				    </button>
					
					<div class="clearfix">
															  
				</div>
			</form>
		</div>
		<!-- header-bot -->
			<div class="col-md-4 logo_agile">
				<h1><a href="index.html"><span></span> Dlite <span>Shopping</span> <i class="fa fa-shopping-bag top_logo_agile_bag" aria-hidden="true"></i></a></h1>
			</div>
        <!-- header-bot -->
		<div class="col-md-4 agileits-social top_content">
						<ul class="social-nav model-3d-0 footer-social w3_agile_social">
						                                   <li class="share">Share On : </li>
															<li><a href="#" class="">
																  <div class="front"><i class="" aria-hidden="true">
																  <img src="<?php echo e(URL::asset('/photos/Google.jpg')); ?>" alt="profile Pic" style="height:30px; width:30px">
																  </i></div>
																  <div class="back"><i class="" aria-hidden="true">
																  <img src="<?php echo e(URL::asset('/photos/Google.jpg')); ?>" alt="profile Pic" style="height:30px; width:30px">
																  </i></div>
																  
																</a></li>
																
																  <li><a href="#" class=""> 
																  <div class="front"><i class="" aria-hidden="true">
																	  <img src="<?php echo e(URL::asset('/photos/facebook.png')); ?>" alt="profile Pic" style="height:30px; width:30px"></i>
																  
																</div>
																  <div class="back"><i class="" aria-hidden="true">
																  <img src="<?php echo e(URL::asset('/photos/facebook.png')); ?>" alt="profile Pic" style="height:30px; width:30px">
																  </i></div></a></li>
															<li><a href="#" class="">
																  <div class="front"><i class="" aria-hidden="true">
																	  
																  <img src="<?php echo e(URL::asset('/photos/Instragram.png')); ?>" alt="profile Pic" style="height:30px; width:30px">
																  </i></div>
																  <div class="back"><i class="" aria-hidden="true">
																  <img src="<?php echo e(URL::asset('/photos/Instragram.png')); ?>" alt="profile Pic" style="height:30px; width:30px">
																  </i></div></a></li>
															<li><a href="#" class="">
																  <div class="front"><i class="" aria-hidden="true">
																	  
																  <img src="<?php echo e(URL::asset('/photos/Twitter.png')); ?>" alt="profile Pic" style="height:30px; width:30px">
																  </i></div>
																  <div class="back"><i class="" aria-hidden="true">
																  <img src="<?php echo e(URL::asset('/photos/Twitter.png')); ?>" alt="profile Pic" style="height:30px; width:30px">
																  </i></div></a></li>
														</ul>



		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!-- banner -->
<div class="ban-top">
	<div class="container">
		<div class="top_nav_left">
			<nav class="navbar navbar-default">
			  <div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<!-- <div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div> -->
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse menu--shylock" id="bs-example-navbar-collapse-1">
				  <ul class="nav navbar-nav menu__list">
					<li class="active menu__item menu__item--current"><a class="menu__link" href="<?php echo e(url('home')); ?>">Home <span class="sr-only">(current)</span></a></li>
					<li class=" menu__item"><a class="menu__link" href="<?php echo e(url('about')); ?>">About</a></li>
					<li class="dropdown menu__item">
						<a href="#" class="dropdown-toggle menu__link dropdown " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">	

  Mens Wears <span class="caret"></span>
  <div class="dropdown-content">
    
											<a href="<?php echo e(('mencloth')); ?>">Clothing</a>
											<a href="<?php echo e(('menwallet')); ?>">Wallets</a>
											<a href="<?php echo e(('menfootwear')); ?>">Footwear</a>
											<a href="<?php echo e(('menwatch')); ?>">Watches</a>
											<a href="<?php echo e(('menbag')); ?>">Bags</a>
											<a href="<?php echo e(('menjewellery')); ?>">Jewellery</a>
											<a href="<?php echo e(('mensunglasses')); ?>">Sunglasses</a>
											<a href="<?php echo e(('menperfume')); ?>">Perfumes</a>
 </div> </a>
						
 
					</li>
					<li class="dropdown menu__item">
						<a href="#" class="dropdown-toggle menu__link dropdown " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">	

  Women Wears <span class="caret"></span>
  <div class="dropdown-content">
    
                                            <a href="<?php echo e(('womencloth')); ?>">Clothing</a>
											<a href="<?php echo e(('womenwallet')); ?>">Wallets</a>
											<a href="<?php echo e(('womenfootwear')); ?>">Footwear</a>
											<a href="<?php echo e(('womenwatch')); ?>">Watches</a>
											<a href="<?php echo e(('womenbag')); ?>">Bags</a>
											<a href="<?php echo e(('womenjewellery')); ?>">Jewellery</a>
											<a href="<?php echo e(('womensunglasses')); ?>">Sunglasses</a>
											<a href="<?php echo e(('womenperfume')); ?>">Perfumes</a>
 </div> </a>
						

					</li>
					<li class="dropdown menu__item">
						<a href="#" class="dropdown-toggle menu__link dropdown " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">	

  Kids <span class="caret"></span>
  <div class="dropdown-content">
    
                                            <a href="<?php echo e(('kidcloth')); ?>">Clothing</a>
											<a href="<?php echo e(('kidwallet')); ?>">Wallets</a>
											<a href="<?php echo e(('kidfootwear')); ?>">Footwear</a>
											<a href="<?php echo e(('kidwatch')); ?>">Watches</a>
											<a href="<?php echo e(('kidbag')); ?>">Bags</a>
											<a href="<?php echo e(('kidjewellery')); ?>">Jewellery</a>
											<a href="<?php echo e(('kidsunglasses')); ?>">Sunglasses</a>
											<a href="<?php echo e(('kidperfume')); ?>">Perfumes</a>
 </div> </a>
						

					</li>
					<li class=" menu__item"><a class="menu__link" href="<?php echo e(url('contact')); ?>">Contact</a></li>
				  </ul>
				</div>
			  </div>
			</nav>	
		</div>
		<div class="top_nav_right">
			<div class="wthreecartaits wthreecartaits2 cart cart box_1"> 
						
						<!-- <input type="hidden" name="cmd" value="_cart">
						<input type="hidden" name="display" value="1"> -->
						<button class="" type="submit" name="submit" value=""><i> <a href="<?php echo e(('cart')); ?>"><img src="<?php echo e(URL::asset('/photos/cart.png')); ?>" alt="profile Pic" style="height:45px; width:45px"></a></i>
				</button>
					  
  
						</div>
		</div>
		
		<div class="clearfix"></div>
	</div>
	
</div>
<?php /**PATH E:\xampp\htdocs\ECommerce\resources\views/header.blade.php ENDPATH**/ ?>