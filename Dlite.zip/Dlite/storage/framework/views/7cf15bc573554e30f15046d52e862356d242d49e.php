<html>
    <head> <title>Ecommerce</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script></head>
    <body>
    

    
        <?php echo e(View::make('header')); ?>

       
        <?php if(session('status')): ?>
        <h2 style="text-align:center" class="alert alert Success"><?php echo e(session('status')); ?></h2>
        <?php endif; ?>
  <div class="container">
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if($Product->Category=="Women"): ?>

<?php if($Product->SubCategory=="Glasses"): ?>
<div class="col-md-3    bg-warning" style="background-color: black;border:1px solid black;margin-top:20px;margin-right:10px;margin-left:10px;height:400px">
<form action="submitcart" method="post">
<?php echo csrf_field(); ?>

<input type="hidden" id="custId" name="name" value="<?php echo e($Product->Name); ?>">
<input type="hidden" id="custId" name="price" value="<?php echo e($Product->Price); ?>">
<input type="hidden" id="custId" name="size" value="<?php echo e($Product->size); ?>">
<input type="hidden" id="custId" name="Userid" value="<?php echo e($loginid); ?>">

<input type="hidden" id="custId" name="Brand" value="<?php echo e($Product->Brand); ?>">
<input type="hidden" id="custId" name="Category" value="<?php echo e($Product->Category); ?>">
<input type="hidden" id="custId" name="SubCategory" value="<?php echo e($Product->SubCategory); ?>">
<input type="hidden" id="custId" name="Discount" value="<?php echo e($Product->Discount); ?>">
<input type="hidden"  name="Image" value="<?php echo e($Product->Image); ?>">

  <div name="image" value="<?php echo e(asset('image/' . $Product->Image)); ?>" style="width:250px;height:250px;border:1px solid black"> <img style="width:250px;height:250px;" src="<?php echo e(asset('image/' . $Product->Image)); ?>" alt="Any alt text"/>  </div>
  <h2 price="name" value="<?php echo e($Product->Name); ?>" style="background-color: Orange;
  color: white;border:1px solid black;font-style: italic;text-align:center" ><?php echo e($Product->Name); ?></h2>
  <h2 name="price" value="<?php echo e($Product->Price); ?>" style="background-color: black;
  color: white;font-style: oblique;font-size: 20px;">Price:     $<?php echo e($Product->Price); ?> 19.6</h2>
  <h2 name="size" style="background-color: black;
  color: white;font-style: oblique;font-size: 20px;">Size:  <?php echo e($Product->size); ?></h2>
  <h2  style="background-color: black;
  color: white;font-style: oblique;font-size:12px;"><?php echo e($Product->Description); ?></h2>
  <h2 name="Userid" value="<?php echo e($loginid); ?>"></h2>
  <h2 name="Brand" value="<?php echo e($Product->Brand); ?>"></h2>
  <h2 name="Category" value="<?php echo e($Product->Category); ?>"></h2>
  <h2 name="SubCategory" value="<?php echo e($Product->SubCategory); ?>"></h2>
  <h2 name="Discount" value="<?php echo e($Product->Discount); ?>"></h2>
  <button  style="background-color: Orange;
  color: white;">Add Cart</button>

</form>

  </div>
  <?php endif; ?>
<?php endif; ?>

<?php echo e($loginid); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>


       <br><br><br><br><br><br><br><br>
      <?php echo e(View::make('footer')); ?>

    
    </body>
</html><?php /**PATH E:\xampp\htdocs\ECommerce\resources\views/Women\sunglasses.blade.php ENDPATH**/ ?>