<html>
        <head>
            <title>Admin</title>
            <style>
                table, th, td {
  border: 1px solid black;
}
            </style>
        </head>
        <body>
        <div>
            <header style="height:100px;width:100%;border:1px solid black">
             <div></div>
            </header>
             <aside style="width:200px;height:100%; border:1px solid black">
             <div ><button style="height:10%;width:100%"><a href="<?php echo e(('login')); ?>">  Dashboard</a></button></div>
             <div ><button style="height:10%;width:100%"><a href="">Sales</a> </button></div>
             <div ><button style="height:10%;width:100%"><a href="">Chats</a> </button></div>
             <div ><button style="height:10%;width:100%"><a href="<?php echo e(('data')); ?>">Account</a> </button></div>
             <div ><button style="height:10%;width:100%"><a href="<?php echo e(('addproduct')); ?>">Add Product</a> </button></div>
             <div ><button style="height:10%;width:100%"><a href="">Edit Product</a> </button></div>
             <div ><button style="height:10%;width:100%"><a href="">Orders</a> </button></div>
             
</aside>
<!-- section part where thing will be shown -->
<div style="position: absolute; top:120px; left:220px;border:1px solid black;width:85%;">


<table>
  <tr>
    <th style="width:80px">Id</th>
    <th style="width:200px">Name</th>
    <th style="width:300px">Email</th>
    <th style="width:200px">Passward</th>
    <th style="width:200px">Edit/Delete</th>
  </tr>
</table>
    <table style="">

         <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td style="width:80px"><?php echo e($user->id); ?></td>
            <td style="width:200px"><?php echo e($user->Name); ?></td>
            <td style="width:300px"><?php echo e($user->Email); ?></td>
            <td style="width:200px"><?php echo e($user->Passward); ?></td>
            <td style="width:200px;text-align:center"><a href=>Edit</a>/
			<a href=''>Delete</a></td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>

</div>
</div>
        </body>
    </html>
  

<?php /**PATH E:\xampp\htdocs\ECommerce\resources\views/Account.blade.php ENDPATH**/ ?>