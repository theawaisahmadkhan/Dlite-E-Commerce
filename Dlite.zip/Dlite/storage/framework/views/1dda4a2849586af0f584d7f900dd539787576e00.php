<div>
            <header style="height:100px;width:100%;border:1px solid black">
             <div></div>
            </header>
             <aside style="width:200px;height:100%; border:1px solid black">
             <div ><button style="height:10%;width:100%"> Womens</button></div>
             <div ><button style="height:10%;width:100%"> Mens</button></div>
             <div ><button style="height:10%;width:100%"> Shoes</button></div>
             <div ><button style="height:10%;width:100%"> Account</button></div>
             <div ><button style="height:10%;width:100%"> Sign In</button></div>
             <div ><button style="height:10%;width:100%"> Sign Out</button></div>
             <div ><button style="height:10%;width:100%"> Orders</button></div>
             
</aside>
</div><?php /**PATH E:\xampp\htdocs\ECommerce\resources\views/welcome.blade.php ENDPATH**/ ?>