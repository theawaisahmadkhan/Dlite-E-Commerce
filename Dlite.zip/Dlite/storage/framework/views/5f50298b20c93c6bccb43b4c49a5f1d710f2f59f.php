<!-- footer -->
<!DOCTYPE html>
<html>
<head>
<title>Elite Shoppy an Ecommerce Online Shopping Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
<!--/tags -->
<!-- <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script> -->
<!--//tags -->
<link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(URL::asset('css/style.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(URL::asset('css/font-awesome.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(URL::asset('css/easy-responsive-tabs.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(URL::asset('css/dropdown.css')); ?>" />
<!-- //for bootstrap working -->
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>


</head>
<body>
<div class="footer">
	<div class="footer_agile_inner_info_w3l">
		<div class="col-md-3 footer-left">
			<h2><a href="index.html"><span></span> Dlite <span>Shopping</span> </a></h2>
			<p>Delite Shopping is an online store that provides branded products for men and women across clothing, 
				footwear, apparel, jewelry, and accessories. The company hosts a wide assortment of consumer electronics,
				 fashion and beauty products, alongside a rapidly growing miscellany of general merchandise.</p>
			<ul class="social-nav model-3d-0 footer-social w3_agile_social two">
			<li class="share">Share On : </li>
															<li><a href="#" class="">
																  <div class="front"><i class="" aria-hidden="true">
																  <img src="<?php echo e(URL::asset('/photos/Google.jpg')); ?>" alt="profile Pic" style="height:30px; width:30px">
																  </i></div>
																  <div class="back"><i class="" aria-hidden="true">
																  <img src="<?php echo e(URL::asset('/photos/Google.jpg')); ?>" alt="profile Pic" style="height:30px; width:30px">
																  </i></div>
																  
																</a></li>
																
																  <li><a href="#" class=""> 
																  <div class="front"><i class="" aria-hidden="true">
																	  <img src="<?php echo e(URL::asset('/photos/facebook.png')); ?>" alt="profile Pic" style="height:30px; width:30px"></i>
																  
																</div>
																  <div class="back"><i class="" aria-hidden="true">
																  <img src="<?php echo e(URL::asset('/photos/facebook.png')); ?>" alt="profile Pic" style="height:30px; width:30px">
																  </i></div></a></li>
															<li><a href="#" class="">
																  <div class="front"><i class="" aria-hidden="true">
																	  
																  <img src="<?php echo e(URL::asset('/photos/Instragram.png')); ?>" alt="profile Pic" style="height:30px; width:30px">
																  </i></div>
																  <div class="back"><i class="" aria-hidden="true">
																  <img src="<?php echo e(URL::asset('/photos/Instragram.png')); ?>" alt="profile Pic" style="height:30px; width:30px">
																  </i></div></a></li>
															<li><a href="#" class="">
																  <div class="front"><i class="" aria-hidden="true">
																	  
																  <img src="<?php echo e(URL::asset('/photos/Twitter.png')); ?>" alt="profile Pic" style="height:30px; width:30px">
																  </i></div>
																  <div class="back"><i class="" aria-hidden="true">
																  <img src="<?php echo e(URL::asset('/photos/Twitter.png')); ?>" alt="profile Pic" style="height:30px; width:30px">
																  </i></div></a></li>
																</ul>
		</div>
		<div class="col-md-9 footer-right">
			<div class="sign-grds">
				<div class="col-md-4 sign-gd">
					<h4>Our <span>Information</span> </h4>
					<ul>
						<li><a href="<?php echo e(url('home')); ?>">Home</a></li>
						<li class="dropdown menu__item">
						<a href="#" class="dropdown-toggle menu__link dropdown " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">	

  Mens Wears <span class="caret"></span>
  <div class="dropdown-content">
    
											<a href="<?php echo e(('mencloth')); ?>">Clothing</a>
											<a href="<?php echo e(('menwallet')); ?>">Wallets</a>
											<a href="<?php echo e(('menfootwear')); ?>">Footwear</a>
											<a href="<?php echo e(('menwatch')); ?>">Watches</a>
											<a href="<?php echo e(('menbag')); ?>">Bags</a>
											<a href="<?php echo e(('menjewellery')); ?>">Jewellery</a>
											<a href="<?php echo e(('mensunglasses')); ?>">Sunglasses</a>
											<a href="<?php echo e(('menperfume')); ?>">Perfumes</a>
 </div> </a>
						
 
					</li>
					<li class="dropdown menu__item">
						<a href="#" class="dropdown-toggle menu__link dropdown " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">	

  Women Wears <span class="caret"></span>
  <div class="dropdown-content">
    
                                            <a href="<?php echo e(('womencloth')); ?>">Clothing</a>
											<a href="<?php echo e(('womenwallet')); ?>">Wallets</a>
											<a href="<?php echo e(('womenfootwear')); ?>">Footwear</a>
											<a href="<?php echo e(('womenwatch')); ?>">Watches</a>
											<a href="<?php echo e(('womenbag')); ?>">Bags</a>
											<a href="<?php echo e(('womenjewellery')); ?>">Jewellery</a>
											<a href="<?php echo e(('womensunglasses')); ?>">Sunglasses</a>
											<a href="<?php echo e(('womenperfume')); ?>">Perfumes</a>
 </div> </a>
						

					</li>
						<li><a href="<?php echo e(url('about')); ?>">About</a></li>
						<li><a href="typography.html">Kids</a></li>
						<li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
					</ul>
				</div>
				
				<div class="col-md-5 sign-gd-two">
					<h4>Store <span>Information</span></h4>
					<div class="w3-address">
						<div class="w3-address-grid">
							<div class="w3-address-left">
								<i class="fa fa-phone" aria-hidden="true"></i>
							</div>
							<div class="w3-address-right">
								<h6>Phone Number</h6>
								<p>+92 306 6423 521</p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="w3-address-grid">
							<div class="w3-address-left">
								<i class="fa fa-envelope" aria-hidden="true"></i>
							</div>
							<div class="w3-address-right">
								<h6>Email Address</h6>
								<p>Email :<a href="mailto:example@email.com"> dlite.shopping@.org.com</a></p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="w3-address-grid">
							<div class="w3-address-left">
								<i class="fa fa-map-marker" aria-hidden="true"></i>
							</div>
							<div class="w3-address-right">
								<h6>Location</h6>
								<p>Lahore St, Cantt 54810 ,Punjab, PAKISTAN. 
								
								</p>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
				</div>
				<div class="col-md-3 sign-gd flickr-post">
					<h4>Flickr <span>Posts</span></h4>
					<ul>
						<li><a href="single.html"><img src="images/t1.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t2.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t3.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t4.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t1.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t2.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t3.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t2.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t4.jpg" alt=" " class="img-responsive" /></a></li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="clearfix"></div>
			<div class="agile_newsletter_footer">
					<div class="col-sm-6 newsleft">
				<h3>SIGN UP FOR NEWSLETTER !</h3>
			</div>
			<div class="col-sm-6 newsright">
			<?php if(session('status')): ?>
        <h2 style="text-align:center" class="alert alert Success"><?php echo e(session('status')); ?></h2>
        <?php endif; ?>
			<form action="/message"  method="post" >
            <?php echo csrf_field(); ?>
          <div class="w3-row-padding" style="margin:0 -16px 8px -16px">
            <div class="w3-half">
				<label style="color:white">Name:</label>
              <input class="w3-input w3-border" type="text" placeholder="Name" required name="Name">
            </div>
            <div class="w3-half">
				 <label style="color:white" for="">Email:</label>
              <input class="w3-input w3-border" type="text" placeholder="Email" required name="Email">
            </div>
          </div>
		 <label style="color:white" for="">  Message:</label>
          <input class="w3-input w3-border" name="Message" type="text" placeholder="Message" required name="Message">
          <button class="w3-button w3-black w3-section w3-right" style="color:white" type="submit">SEND</button>
        </form>
			</div>

		<div class="clearfix"></div>
	</div>
		<p class="copy-right">&copy 2022 Dlite Shooping. All rights reserved </p>
	</div>
</div>
<!-- //footer --><?php /**PATH E:\xampp\htdocs\ECommerce\resources\views/footer.blade.php ENDPATH**/ ?>