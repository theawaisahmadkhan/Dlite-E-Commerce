

<!DOCTYPE html>
<html lang="en">
<head>
<title> Dlite Shopping About </title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
</head>
<body>
<?php echo e(View::make('header')); ?>


<?php echo $__env->yieldContent('content'); ?>


  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band">
    <h2 class="w3-wide">Dlite Shopping </h2>
    <p class="w3-opacity"><i>We love shopping</i></p>
    <p class="w3-justify">
    Dlite Shopping is the leading e-commerce marketplace in Pakistan.Delite Shopping is an online store that provides 
          branded products for men and women across clothing, 
				footwear, apparel, jewelry, and accessories. The company hosts a wide assortment of consumer electronics,
				 fashion and beauty products, alongside a rapidly growing miscellany of general merchandise.in full electronic 
         commerce, maintaining relationships and conducting business transactions that include selling information,
          services, and goods by means of computer telecommunications networks.


</div>

<?php echo e(View::make('footer')); ?>

</body>
</html>
<?php /**PATH E:\xampp\htdocs\ECommerce\resources\views/About.blade.php ENDPATH**/ ?>