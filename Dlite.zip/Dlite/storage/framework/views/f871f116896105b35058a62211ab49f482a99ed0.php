<title>Dlite Shopping Cart</title>
<?php echo e(View::make('header')); ?>


        <?php echo $__env->yieldContent('content'); ?>
        <br><br><br><br>
        <?php if(session('status')): ?>
        <h2 style="text-align:center" class="alert alert Success"><?php echo e(session('status')); ?></h2>
        <?php endif; ?>
        <div  style="margin:5%">
        <table>
              <tr>
                    <th style="width:80px;border:1px solid black;background-color:Orange;">Image</th>
                    <th style="width:150px;border:1px solid black;background-color:Orange">Product Name</th>
                    <th style="width:200px;border:1px solid black;background-color:Orange"> Quantity</th>
                    <th style="width:80px;border:1px solid black;background-color:Orange">Price</th>
              </tr>
        </table>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php if($loginid!=0): ?>
       
            <form action="orderproduct" method="post" >
             <?php echo csrf_field(); ?>
             <input type="hidden" name="id" value="<?php echo e($Product->id); ?>">
             <input type="hidden" name="Name" value="<?php echo e($Product->Name); ?>">
             <input type="hidden" name="Image" value="<?php echo e($Product->Image); ?>">
             <input type="hidden" name="Price" value="<?php echo e($Product->Price); ?>">
             <input type="hidden" name="Userid" value="<?php echo e($Product->Userid); ?>">
             <input type="hidden" name="Discount" value="<?php echo e($Product->Discount); ?>">
             <input type="hidden" name="Brand" value="<?php echo e($Product->Brand); ?>">
             <input type="hidden" name="Category" value="<?php echo e($Product->Category); ?>">
             <input type="hidden" name="SubCategory" value="<?php echo e($Product->SubCategory); ?>">
         <table style="border:1px solid Orange">
         <br>
         <tr style="border:1px solid Orange">
            <td style=";;"><img style="width:80px;height:100px;" src="<?php echo e(asset('image/' . $Product->Image)); ?>" alt="Any alt text"/>
            <td style="width:150px;border:1px solid black;background-color:grey;color:white;font-size:16px;text-align:center"><?php echo e($Product->Name); ?></td>
            <td style="width:100px;border:1px solid black;background-color:Orange;">
            <input type="text" value="" name="Quantity" required="Please Enetr Quantity" placeholder="Enter Your Quantity"></td>
            <td style="width:80px;border:1px solid black;background-color:grey;color:white;font-size:16px">$<?php echo e($Product->Price); ?></td>
            <td style=";text-align:center;color:Black ;font-size:16px;background-color:Orange"><button type="submit">Order</button>/
            <button><a href='deletecart/<?php echo e($Product->id); ?>'>Delete</a></button>
			</td>
         </tr>
        
         </table>
         </form>
       
       <?php endif; ?>
        
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
        </div>
        


  <?php echo e(View::make('footer')); ?><?php /**PATH E:\xampp\htdocs\ECommerce\resources\views/Cart.blade.php ENDPATH**/ ?>