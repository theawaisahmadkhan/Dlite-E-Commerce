<html>
        <head>
            <title>Edit Products</title>
            <style>
                table, th, td {
  border: 1px solid black;
}
            </style>
        </head>
        <body>
        <div>
        <header style="height:100px;width:117%;border:1px solid black;background-color:Orange">

<!-- <div> <img style="height:100px;width:40%;"src="<?php echo e(URL::asset('/photos/delite.jpg')); ?>" alt=""></div> -->
<h1 style="text-align:center;font-size:60px;vertical-align: text-top; text-shadow: 2px 2px white;">Dlite Shopping</h1>
</header>
<aside style="width:200px;height:100%; border:1px solid black">
<div ><button style="height:10%;width:100%;background-color:Orange;"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;" href="<?php echo e(('admin')); ?>">  Dashboard</a></button></div>
<div ><button style="height:10%;width:100%;"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;"href="<?php echo e(('sales')); ?>">Sales</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;;text-shadow: 2px 2px black;"href="<?php echo e(('chat')); ?>">Chats</a> </button></div>
<div ><button style="height:10%;width:100%"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;" href="<?php echo e(('data')); ?>">Account</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;"href="<?php echo e(('addproduct')); ?>">Add Product</a> </button></div>
<div ><button style="height:10%;width:100%"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;"href="<?php echo e(('editproduct')); ?>">Edit Product</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;"href="<?php echo e(('orderdata')); ?>">Orders</a> </button></div>

</aside>
<!-- section part where thing will be shown -->
<div style="position: absolute; top:120px; left:220px;border:1px solid black;width:100%;">


<table>
  <tr>
    <th style="width:20%">Image</th>
    <th style="width:15%">Product Name</th>
    <th style="width:15%">Discount</th>
    <th style="width:15%">Quantity</th>
    <th style="width:12%">Price</th>
    <th style="width:8%">Category</th>
    <th style="width:10%">SubCategory</th>
    <th style="width 10%">Edit/Delete</th>
  </tr>
</table>
    
<?php if(session('status')): ?>
        <h2 style="text-align:center" class="alert alert Success"><?php echo e(session('status')); ?></h2>
        <?php endif; ?>
         <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <form action="updateproduct" method="post" enctype="multipart/form-data">
             <?php echo csrf_field(); ?>
             <input type="hidden" name="id" value="<?php echo e($Product->id); ?>">
         <table style="">
         <br>
         <tr>
            <td style="width:18%"><img style="width:80px;height:100px;" src="<?php echo e(asset('image/' . $Product->Image)); ?>" alt="Any alt text"/>
        <input type="file" name="Image" value="">
        </td>
            <td style="width:12%;color:Black ;font-size:16px;background-color:Orange">Edit Name:<input type="text" name="Name" value="<?php echo e($Product->Name); ?>" placeholder="Edit Product Name">Name: <?php echo e($Product->Name); ?></td>
            <td style="width:12%;color:Black ;font-size:16px;background-color:Orange">Edit Discount: <input type="text" name="Discount" value="<?php echo e($Product->Discount); ?>" placeholder="Edit Product Discount">Discount:<?php echo e($Product->Discount); ?></td>
            <td style="width:12%;color:Black ;font-size:16px;background-color:Orange">Edit Quantity<input type="text" name="Quantity" value="<?php echo e($Product->Quantity); ?>" placeholder="Edit Product Quantity">Quantity:<?php echo e($Product->Quantity); ?></td>
            <td style="width:12%;color:Black ;font-size:16px;background-color:Orange">Edit Price<input type="text" name="Price" value="<?php echo e($Product->Price); ?>" placeholder="Edit Product Price">Price:<?php echo e($Product->Price); ?></td>
            <td style="width:8%;color:Black ;font-size:16px;background-color:Orange"> Edit Category:
                <select name="product_categorie" value="<?php echo e($Product->Category); ?>">
       <option value="Men">Men</option>
       <option  value="Women">Women</option>
       <option  value="Kid">Kid</option>
    </select><?php echo e($Product->Category); ?></td>

        <td style="width:10%;color:Black ;font-size:16px;background-color:Orange"> Edit SubCategory<select name="product_subcategorie" value="<?php echo e($Product->SubCategory); ?>">
         <option   value="Cloths">Cloths</option>
         <option value="Shoes">Shoes</option>
         <option value="Watches">Watches</option>
         <option value="Bag">Bag</option>
         <option value="Jewelllery">Jewellery</option>
         <option value="Perfume">Perfume</option>
         <option value="Wallet">Wallet</option>
         <option value="Glasses">Glasses</option>
         </select><?php echo e($Product->SubCategory); ?></td>
            <td style="width:10%;text-align:center;color:Black ;font-size:16px;background-color:Orange"><button type="submit">Edit</button>/
            <button><a href='deleteproduct/<?php echo e($Product->id); ?>'>Delete</a></button>
			</td>
         </tr>
        
         </table>
         </form>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     

</div>
</div>
        </body>
    </html>
  

<?php /**PATH E:\xampp\htdocs\ECommerce\resources\views/EditProduct.blade.php ENDPATH**/ ?>