<html>
        <head>
            <title>Accounts</title>
            <style>
                table, th, td {
  border: 1px solid black;
}
            </style>
        </head>
        <body>
        <div>
        <header style="height:100px;width:102%;border:1px solid black;background-color:Orange">

<!-- <div> <img style="height:100px;width:40%;"src="<?php echo e(URL::asset('/photos/delite.jpg')); ?>" alt=""></div> -->
<h1 style="text-align:center;font-size:60px;vertical-align: text-top; text-shadow: 2px 2px white;">Dlite Shopping</h1>
</header>
<aside style="width:200px;height:100%; border:1px solid black">
<div ><button style="height:10%;width:100%;background-color:Orange;"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;" href="<?php echo e(('admin')); ?>">  Dashboard</a></button></div>
<div ><button style="height:10%;width:100%;"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;"href="<?php echo e(('sales')); ?>">Sales</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;;text-shadow: 2px 2px black;"href="<?php echo e(('chat')); ?>">Chats</a> </button></div>
<div ><button style="height:10%;width:100%"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;" href="<?php echo e(('data')); ?>">Account</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;"href="<?php echo e(('addproduct')); ?>">Add Product</a> </button></div>
<div ><button style="height:10%;width:100%"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;"href="<?php echo e(('editproduct')); ?>">Edit Product</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;"href="<?php echo e(('orderdata')); ?>">Orders</a> </button></div>

</aside>
<!-- section part where thing will be shown -->
<div style="position: absolute; top:120px; left:220px;border:1px solid black;width:85%;">

<?php if(session('status')): ?>
        <h2 style="text-align:center" class="alert alert Success"><?php echo e(session('status')); ?></h2>
        <?php endif; ?>
<table>
  <tr>
    <th style="width:80px">Id</th>
    <th style="width:200px">Name</th>
    <th style="width:300px">Email</th>
    <th style="width:200px">Passward</th>
    <th style="width:200px">Edit/Delete</th>
  </tr>
</table>

    <table style="">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="updateaccount" method="post">
          <?php echo csrf_field(); ?>
         <tr>
            <td style="width:80px"><input type="hidden" name="id" value="<?php echo e($user->id); ?>">  <?php echo e($user->id); ?></td>
            
            <td style="width:200px ;color:Black ;font-size:16px;background-color:Orange">  Edit Name: <input type="text" name="Name" value="<?php echo e($user->Name); ?>" placeholder="Edit Name"> Name:<?php echo e($user->Name); ?></td>
            <td style="width:300px;color:Black ;font-size:16px;background-color:Orange">Edit Email:<input type="text" name="Email" value="<?php echo e($user->Email); ?>" placeholder="Edit Email"> Email:<?php echo e($user->Email); ?></td>
            <td style="width:200px;color:Black ;font-size:16px;background-color:Orange">Edit Passward: <input type="text" name="Passward" value="<?php echo e($user->Passward); ?>" placeholder="Edit Passward">Passward: <?php echo e($user->Passward); ?></td>
            <td style="width:200px;text-align:center ;background-color:Orange"><button type="submit">Edit</button>/
			<button><a href='delete/<?php echo e($user->id); ?>'>Delete</a></button></td>
         </tr>
         </form>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
     

</div>
</div>
        </body>
    </html>
  

<?php /**PATH E:\xampp\htdocs\ECommerce\resources\views/account.blade.php ENDPATH**/ ?>