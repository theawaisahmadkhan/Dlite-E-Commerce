<html>
    <head>
      <title>Dlite Shopping Contact</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
    <?php echo e(View::make('header')); ?>

    <?php if(session('status')): ?>
        <h2 style="text-align:center" class="alert alert Success"><?php echo e(session('status')); ?></h2>
        <?php endif; ?>
    <div class="w3-container w3-content w3-padding-64" style="max-width:800px" id="contact">
    <h2 class="w3-wide w3-center">CONTACT</h2>
    <p class="w3-opacity w3-center"><i> Drop a note!</i></p>
    <div class="w3-row w3-padding-32">
      <div class="w3-col m6 w3-large w3-margin-bottom">
        <i class="fa fa-map-marker" style="width:30px"></i> Lahore St, Cantt 54810 ,Punjab, PAKISTAN.<br>
        <i class="fa fa-phone" style="width:30px"></i> Phone: +92 306 6423 521<br>
        <i class="fa fa-envelope" style="width:30px"> </i> Email: dlite.shopping@.org.com<br>
      </div>
      <div class="w3-col m6">
        <form action="/message"  method="post" >
            <?php echo csrf_field(); ?>
          <div class="w3-row-padding" style="margin:0 -16px 8px -16px">
            <div class="w3-half">
              <input class="w3-input w3-border" type="text" placeholder="Name" required name="Name">
            </div>
            <div class="w3-half">
              <input class="w3-input w3-border" type="text" placeholder="Email" required name="Email">
            </div>
          </div>
          <input class="w3-input w3-border" name="Message" type="text" placeholder="Message" required name="Message">
          <button class="w3-button w3-black w3-section w3-right" type="submit">SEND</button>
        </form>
      </div>
    </div>
  </div>
  
<?php echo e(View::make('footer')); ?>

    </body>
</html><?php /**PATH E:\xampp\htdocs\ECommerce\resources\views/contact.blade.php ENDPATH**/ ?>