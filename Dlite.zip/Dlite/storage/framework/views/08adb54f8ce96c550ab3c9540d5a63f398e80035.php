<html>
        <head>
            <title>Sales</title>
            <style>
                table, th, td {
  border: 1px solid black;
}
            </style>
        </head>
        <body>
        <div>
            <header style="height:100px;width:102%;border:1px solid black;background-color:Orange">

             <!-- <div> <img style="height:100px;width:40%;"src="<?php echo e(URL::asset('/photos/delite.jpg')); ?>" alt=""></div> -->
            <h1 style="text-align:center;font-size:60px;vertical-align: text-top; text-shadow: 2px 2px white;">Dlite Shopping</h1>
            </header>
             <aside style="width:200px;height:100%; border:1px solid black">
             <div ><button style="height:10%;width:100%;background-color:Orange;"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;" href="<?php echo e(('admin')); ?>">  Dashboard</a></button></div>
<div ><button style="height:10%;width:100%;"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;"href="<?php echo e(('sales')); ?>">Sales</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;;text-shadow: 2px 2px black;"href="<?php echo e(('chat')); ?>">Chats</a> </button></div>
<div ><button style="height:10%;width:100%"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;" href="<?php echo e(('data')); ?>">Account</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;"href="<?php echo e(('addproduct')); ?>">Add Product</a> </button></div>
<div ><button style="height:10%;width:100%"><a style="color:black;font-size:25px;text-shadow: 2px 2px grey;"href="<?php echo e(('editproduct')); ?>">Edit Product</a> </button></div>
<div ><button style="height:10%;width:100%;background-color:Orange"><a style="color:white;font-size:25px;text-shadow: 2px 2px black;"href="<?php echo e(('orderdata')); ?>">Orders</a> </button></div>

</aside>
<!-- section part where thing will be shown -->
<div style="position: absolute; top:120px; left:220px;border:1px solid black;width:85%;">
<?php if(session('status')): ?>
        <h2 style="text-align:center" class="alert alert Success"><?php echo e(session('status')); ?></h2>
        <?php endif; ?>

<table>
  <tr>
    <th style="width:80px">Image</th>
    <th style="width:50px;text-align:center;background-color:Orange">Id</th>
    <th style="width:70px;text-align:center">Name</th>
    <th style="width:75px;text-align:center;background-color:Orange">ProductId</th>
    <th style="width:75px;text-align:center">Product Name</th>
    <th style="width:75px;text-align:center;background-color:Orange">Category</th>
    <th style="width:80px;text-align:center">SubCategory</th>
    <th style="width:70px;text-align:center;background-color:Orange">Price</th>
    <th style="width:70px;text-align:center">Quantity</th>
    <th style="width:75px;text-align:center;background-color:Orange">Brand</th>
    <th style="width:75px;text-align:center">Discount</th>
    <th style="width:70px;text-align:center;background-color:Orange">Status</th>
  </tr>
</table>

    <table style="">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <br>
          <?php echo csrf_field(); ?>
         <tr>
             <td style=""><img style="width:80px;height:100px" src="<?php echo e(asset('image/' . $user->Image)); ?>" alt=""></td>
             <td style="width:50px;text-align:center;background-color:Orange"><?php echo e($user->id); ?></td>
             <td style="width:80px;text-align:center"><?php echo e($user->UserName); ?></td>
             <td style="width:80px;text-align:center;background-color:Orange"><?php echo e($user->ProductId); ?></td>
             <td style="width:80px;text-align:center"><?php echo e($user->ProductName); ?></td>
             <td style="width:80px;text-align:center;background-color:Orange"><?php echo e($user->Category); ?></td>
             <td style="width:80px;text-align:center"><?php echo e($user->SubCategory); ?></td>
             <td style="width:80px;text-align:center;background-color:Orange"><?php echo e($user->Price); ?></td>
             <td style="width:80px;text-align:center"><?php echo e($user->Quantity); ?></td>
             <td style="width:80px;text-align:center;background-color:Orange"><?php echo e($user->Brand); ?></td>
             <td style="width:80px;text-align:center"><?php echo e($user->Discount); ?></td>
             <td style="width:80px;text-align:center;background-color:Orange"><?php echo e($user->Status); ?></td>
             
           
            <td style="width:200px;text-align:center ;background-color:Orange">
            <button><a href='deleteorder/<?php echo e($user->id); ?>'>Delete Sales List</a></button></td>
         </tr>
         
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
     

</div>
</div>
        </body>
    </html>
  

<?php /**PATH E:\xampp\htdocs\ECommerce\resources\views/Sales.blade.php ENDPATH**/ ?>